document.addEventListener('DOMContentLoaded', function () {
    const busquedaInput = document.getElementById('busqueda');

    busquedaInput.addEventListener('input', () => {
        const filtro = busquedaInput.value.trim().toLowerCase();
        const productos = document.querySelectorAll('.producto-item');

        productos.forEach(producto => {
            const nombre = producto.getAttribute('data-nombre');
            producto.style.display = nombre.includes(filtro) ? '' : 'none';
        });
    });
});

function mostrarModalAgregar(id, nombre, stock, imagenUrl) {
    const modal = new bootstrap.Modal(document.getElementById('modalAgregar'));

    document.getElementById('modalIdProducto').value = id;
    document.getElementById('modalNombreProducto').innerText = nombre;
    document.getElementById('modalStock').innerText = `Stock disponible: ${stock}`;
    document.getElementById('modalCantidad').value = 1;
    document.getElementById('modalCantidad').max = stock;
    document.getElementById('modalImagen').src = imagenUrl;

    modal.show();
}

document.addEventListener('DOMContentLoaded', function () {

    // === GESTIÓN DEL MENÚ DESPLEGABLE DEL PERFIL ===
    const profileDropdown = document.querySelector('.profile-dropdown');
    const dropdownMenu = document.getElementById('dropdown-menu');

    if (profileDropdown) {
        profileDropdown.addEventListener('click', function (event) {
            // Evita que el click se propague al 'document' y cierre el menú inmediatamente
            event.stopPropagation();
            dropdownMenu.style.display = (dropdownMenu.style.display === 'block') ? 'none' : 'block';
        });
    }

    // Cierra el menú del perfil si se hace clic en cualquier otro lugar
    document.addEventListener('click', function () {
        if (dropdownMenu) {
            dropdownMenu.style.display = 'none';
        }
    });

    // === GESTIÓN GENERAL DE SUBMENÚS ===
    // Selecciona todos los elementos que activan un submenú
    const submenuTriggers = document.querySelectorAll('.submenu > a');

    submenuTriggers.forEach(trigger => {
        trigger.addEventListener('click', function (e) {
            e.preventDefault(); // Previene la navegación

            // Encuentra el submenú correspondiente (el elemento <ul> hermano)
            const submenu = this.nextElementSibling;
            
            // Alterna la visibilidad del submenú clickeado
            if (submenu && submenu.classList.contains('submenu-items')) {
                const icon = this.querySelector('.fa-caret-down');
                
                if (submenu.style.display === 'block') {
                    submenu.style.display = 'none';
                    if(icon) icon.style.transform = 'rotate(0deg)'; // Rota el ícono hacia abajo
                } else {
                    submenu.style.display = 'block';
                    if(icon) icon.style.transform = 'rotate(-180deg)'; // Rota el ícono hacia arriba
                }
            }
        });
    });

    // === AJUSTE PARA LOS ENLACES DEL IFRAME ===
    // Asegurarse de que al hacer clic en un enlace del submenú, este se cierre.
    const iframeLinks = document.querySelectorAll('.submenu-items a');

    iframeLinks.forEach(link => {
        link.addEventListener('click', function() {
            // No es necesario, ya que el iframe se carga y la página no se recarga,
            // pero si quisieras cerrar todos los submenús al hacer clic, podrías hacerlo aquí.
            // Por ejemplo:
            // document.querySelectorAll('.submenu-items').forEach(sub => sub.style.display = 'none');
        });
    });
});
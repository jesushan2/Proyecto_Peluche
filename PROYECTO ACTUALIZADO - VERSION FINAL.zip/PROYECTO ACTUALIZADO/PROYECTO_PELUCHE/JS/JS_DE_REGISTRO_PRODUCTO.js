document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('formRegistroProducto');

    form.addEventListener('submit', function (e) {
        const textoRegex = /^[a-zA-Z0-9\sáéíóúÁÉÍÓÚñÑ.,-]+$/;
        const precioRegex = /^\d+(\.\d{2})$/;

        const nombre = form.nombre_prod.value.trim();
        const descripcion = form.descripcion.value.trim();
        const altura = form.altura.value.trim();
        const color = form.color.value.trim();
        const stock = form.stock.value.trim();
        const precio = form.precio.value.trim();

        for (let campo of [nombre, descripcion, altura, color]) {
            if (!textoRegex.test(campo)) {
                alert("Evite usar caracteres especiales en los campos de texto.");
                e.preventDefault();
                return;
            }
        }

        if (!/^\d{1,4}$/.test(stock)) {
            alert("El stock debe ser un número de hasta 4 dígitos.");
            e.preventDefault();
            return;
        }

        if (!precioRegex.test(precio)) {
            alert("El precio debe tener dos decimales, por ejemplo: 10.00");
            e.preventDefault();
            return;
        }
    });
});

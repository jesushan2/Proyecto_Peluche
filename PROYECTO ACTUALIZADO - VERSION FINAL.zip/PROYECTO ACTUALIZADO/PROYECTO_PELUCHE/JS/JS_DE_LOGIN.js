document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('loginForm');

    form.addEventListener('submit', function (e) {
        const correo = document.getElementById('correo').value.trim();
        const contraseña = document.getElementById('contraseña').value.trim();

        const correoValido = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(correo);
        const contraseñaValida = /^[A-Za-z0-9]{4,12}$/.test(contraseña);

        if (!correo || !contraseña) {
            alert("Por favor, complete todos los campos.");
            e.preventDefault();
            return;
        }

        if (!correoValido) {
            alert("El formato del correo no es válido.");
            e.preventDefault();
            return;
        }

        if (!contraseñaValida) {
            alert("La contraseña debe contener entre 4 y 12 caracteres, solo letras y números.");
            e.preventDefault();
        }
    });
});
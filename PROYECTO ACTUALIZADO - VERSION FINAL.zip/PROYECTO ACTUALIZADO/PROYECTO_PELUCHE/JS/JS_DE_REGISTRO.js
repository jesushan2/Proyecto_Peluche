document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('registroForm');
    const errorDiv = document.getElementById('erroresCliente');

    form.addEventListener('submit', function (e) {
        const nombre = document.getElementById('nombres').value.trim();
        const apellido = document.getElementById('apellidos').value.trim();
        const telefono = document.getElementById('telefono').value.trim();
        const correo = document.getElementById('correo').value.trim();
        const contraseña = document.getElementById('contraseña').value.trim();

        let errores = [];

        if (!nombre || nombre.length < 2) errores.push("⚠️ El nombre es obligatorio.");
        if (!apellido || apellido.length < 2) errores.push("⚠️ El apellido es obligatorio.");
        if (!/^[0-9]{9}$/.test(telefono)) errores.push("⚠️ El teléfono debe tener exactamente 9 dígitos numéricos.");
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo)) errores.push("⚠️ Ingrese un correo válido.");
        if (contraseña.length < 4 || contraseña.length > 12) errores.push("⚠️ La contraseña debe tener entre 4 y 12 caracteres.");

        if (errores.length > 0) {
            e.preventDefault();
            errorDiv.innerHTML = "<ul><li>" + errores.join("</li><li>") + "</li></ul>";
            errorDiv.style.display = "block";
        }
    });
});


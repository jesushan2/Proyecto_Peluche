document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("formRegistroVendedor");
    form.addEventListener("submit", function (e) {
        const telefono = form.telefono.value.trim();
        if (!/^\d{9}$/.test(telefono)) {
            e.preventDefault();
            alert("El teléfono debe tener 9 dígitos numéricos.");
        }
    });
});

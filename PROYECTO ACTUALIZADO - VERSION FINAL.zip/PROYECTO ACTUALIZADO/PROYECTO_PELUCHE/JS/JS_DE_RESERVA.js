// Define ruta base del proyecto
const baseURL = "/PROYECTO_PELUCHE";

// Modal para quitar productos del carrito
function mostrarModalEliminar(idProducto, cantidadActual, nombreProducto) {
    const modal = new bootstrap.Modal(document.getElementById('modalEliminar'));
    document.getElementById('modalIdProducto').value = idProducto;
    document.getElementById('modalCantidad').value = 1;
    document.getElementById('modalCantidad').max = cantidadActual;
    document.getElementById('stockHelp').innerText = `Cantidad máxima: ${cantidadActual}`;
    document.getElementById('labelCantidad').innerText = `¿Cuántos '${nombreProducto}' deseas quitar del carrito?`;
    modal.show();
}

// Modal de confirmación de reserva
function mostrarModalWhatsapp() {
    const modal = new bootstrap.Modal(document.getElementById('modalWhatsapp'));
    modal.show();
}

// Procesa la reserva y redirige a WhatsApp
function procesarYRedirigir() {
    fetch(baseURL + "/reserva/procesarReserva", {
        method: "POST",
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(res => res.text())
    .then(() => {
        const mensaje = encodeURIComponent("Hola, acabo de procesar mi reserva y deseo coordinar la entrega.");
        const url = "https://wa.me/51902045967?text=" + mensaje;
        window.open(url, "_blank");

        // Oculta el modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('modalWhatsapp'));
        if (modal) modal.hide();

        // Quita el contenido del carrito
        const carrito = document.getElementById('carritoContent');
        if (carrito) carrito.remove();

        // Muestra mensaje de éxito
        const alerta = document.createElement('div');
        alerta.className = 'alert alert-success mt-4';
        alerta.textContent = "¡Reserva procesada con éxito!";
        document.getElementById('alertas').appendChild(alerta);
    })
    .catch(error => {
        alert("Hubo un error al procesar la reserva.");
        console.error(error);
    });
}

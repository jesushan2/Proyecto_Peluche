function handleCredentialResponse(response) {
    const token = response.credential;

    fetch("/PROYECTO_PELUCHE/login/googleLogin", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: "credential=" + encodeURIComponent(token)
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            window.location.href = "/PROYECTO_PELUCHE/home/index";
        } else {
            alert("Error: " + (data.message || "Error desconocido."));
        }
    })
    .catch(err => {
        console.error("Error en login con Google:", err);
        alert("Hubo un problema con Google Sign-In.");
    });
}



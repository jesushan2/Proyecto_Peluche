function validarFormularioAdmin() {
    const telefono = document.querySelector('input[name="telefono"]');
    const clave = document.querySelector('input[name="clave"]');
    const nombres = document.querySelector('input[name="nombres"]');
    const apellidos = document.querySelector('input[name="apellidos"]');
    const correo = document.querySelector('input[name="correo"]');

    const textoRegex = /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/;
    const telefonoRegex = /^\d{9}$/;
    const correoRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const passRegex = /^(?=.*[A-Za-z])(?=.*\d).{6,}$/;

    telefono.value = telefono.value.trim();
    clave.value = clave.value.trim();
    nombres.value = nombres.value.trim();
    apellidos.value = apellidos.value.trim();
    correo.value = correo.value.trim();

    if (!textoRegex.test(nombres.value)) {
        alert("Los nombres solo deben contener letras y espacios.");
        return false;
    }
    if (!textoRegex.test(apellidos.value)) {
        alert("Los apellidos solo deben contener letras y espacios.");
        return false;
    }

    if (!telefonoRegex.test(telefono.value)) {
        alert("El teléfono debe tener exactamente 9 dígitos.");
        return false;
    }

    if (!correoRegex.test(correo.value)) {
        alert("Ingrese un correo electrónico válido.");
        return false;
    }

    if (!passRegex.test(clave.value)) {
        alert("La contraseña debe tener al menos 6 caracteres, incluyendo letras y números.");
        return false;
    }

    return true;
}

<?php
session_start();

// Detecta si estamos en el panel admin (basado en ruta URL)
$uri = $_SERVER['REQUEST_URI'];
$esAdmin = strpos($uri, '/admin') !== false;

// Establece la carpeta base según la sección
$baseCarpeta = $esAdmin ? 'admin' : 'app';

// Extrae la ruta limpia
$path = trim(parse_url($uri, PHP_URL_PATH), '/');
$segmentos = explode('/', $path);

// Detecta el nombre de la carpeta del proyecto
$carpetaProyecto = basename(__DIR__);
$baseIndex = array_search($carpetaProyecto, $segmentos);

// Calcula controlador y acción
if ($esAdmin) {
    $controller = $segmentos[$baseIndex + 2] ?? 'login';
    $action     = $segmentos[$baseIndex + 3] ?? 'index';
    $param      = $segmentos[$baseIndex + 4] ?? null;  // Nuevo: posible parámetro (como ID)
} else {
    $controller = $segmentos[$baseIndex + 1] ?? 'login';
    $action     = $segmentos[$baseIndex + 2] ?? 'index';
    $param      = $segmentos[$baseIndex + 3] ?? null;  // Nuevo: posible parámetro (como ID)
}

// Aplica el prefijo "AD" solo si estás en admin
$controllerClass = ($esAdmin ? 'AD' : '') . ucfirst($controller) . 'Controller';
$controllerFile  = __DIR__ . "/$baseCarpeta/controllers/$controllerClass.php";

// Carga y ejecuta
if (file_exists($controllerFile)) {
    require_once $controllerFile;

    if (class_exists($controllerClass)) {
        $instancia = new $controllerClass();

        if (method_exists($instancia, $action)) {
            // ✅ Verifica si hay un parámetro y pásalo
            if ($param !== null) {
                $instancia->$action($param);
            } else {
                $instancia->$action();
            }
        } else {
            http_response_code(404);
            echo "<h2>❌ Acción '<strong>$action</strong>' no encontrada en <strong>$controllerClass</strong>.</h2>";
        }
    } else {
        http_response_code(500);
        echo "<h2>❌ Clase <strong>$controllerClass</strong> no definida.</h2>";
    }
} else {
    http_response_code(404);
    echo "<h2>❌ Controlador <code>$controllerFile</code> no encontrado.</h2>";
}

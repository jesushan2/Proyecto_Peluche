<?php
if (session_status() === PHP_SESSION_NONE) session_start();

require_once __DIR__ . '/../templates/header.php';
?>

<div class="wrapper d-flex flex-column min-vh-100">
<main class="flex-grow-1">

<div class="container mt-4">
    <h3 class="mb-4">Mi Historial de Reservas</h3>
    <input type="text" id="buscador" class="form-control buscar" placeholder="Buscar por número de reserva...">

    <table class="table table-bordered mt-3">
        <thead class="table-light">
            <tr>
                <th>N° Reserva</th>
                <th>Fecha</th>
                <th>Total (S/)</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody id="tabla-historial">
            <?php foreach ($historial as $reserva): ?>
                <tr>
                    <td><?= htmlspecialchars($reserva['id_reserva']) ?></td>
                    <td><?= htmlspecialchars($reserva['fecha_reserva']) ?></td>
                    <td><?= number_format($reserva['total'], 2) ?></td>
                    <td>
                        <a class="btn btn-info btn-sm"
                           href="/PROYECTO_PELUCHE/reserva/verDetalleUsuario?id=<?= $reserva['id_reserva'] ?>">
                           Ver detalles
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

</main>
<?php require_once __DIR__ . '/../templates/footer.php'; ?>
</div>

<script>
    const input = document.getElementById("buscador");
    const filas = document.querySelectorAll("#tabla-historial tr");

    input.addEventListener("input", () => {
        const filtro = input.value.toLowerCase();
        filas.forEach(fila => {
            const texto = fila.textContent.toLowerCase();
            fila.style.display = texto.includes(filtro) ? "" : "none";
        });
    });
</script>

<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../../controllers/ReservaController.php';

$baseURL = '/PROYECTO_PELUCHE';
$token = ReservaController::generarCsrfToken();
?>

<div class="container mt-4">
    <h2>Mi Carrito de Reservas</h2>

    <div id="alertas">
        <?php if (isset($_SESSION['mensaje'])): ?>
            <div class="alert alert-success"><?= htmlspecialchars($_SESSION['mensaje']); unset($_SESSION['mensaje']); ?></div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
        <?php endif; ?>
    </div>

    <?php if (!empty($_SESSION['carrito'])): ?>
        <div id="carritoContent">
            <div class="table-responsive">
                <table class="table table-bordered align-middle text-center">
                    <thead class="table-dark">
                        <tr>
                            <th>Imagen</th>
                            <th>Producto</th>
                            <th>Precio</th>
                            <th>Cantidad</th>
                            <th>Subtotal</th>
                            <th>Eliminar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $total = 0; ?>
                        <?php foreach ($_SESSION['carrito'] as $item): ?>
                            <?php
                            $subtotal = $item['precio'] * $item['cantidad'];
                            $total += $subtotal;
                            ?>
                            <tr>
                                <td><img src="<?= $baseURL ?>/image/<?= htmlspecialchars($item['imagen']) ?>" width="60" alt="Producto"></td>
                                <td><?= htmlspecialchars($item['nombre']) ?></td>
                                <td>S/. <?= number_format($item['precio'], 2) ?></td>
                                <td><?= (int)$item['cantidad'] ?></td>
                                <td>S/. <?= number_format($subtotal, 2) ?></td>
                                <td>
                                    <button class="btn btn-danger btn-sm"
                                        onclick="mostrarModalEliminar(<?= (int)$item['id_producto'] ?>, <?= (int)$item['cantidad'] ?>, '<?= htmlspecialchars($item['nombre'], ENT_QUOTES) ?>')">
                                        ❌
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <h4 class="mt-3">Total: <strong>S/. <?= number_format($total, 2) ?></strong></h4>

            <div class="mt-3 d-flex gap-3 flex-wrap">
                <button type="button" class="btn btn-success" onclick="mostrarModalWhatsapp()">Procesar Reserva</button>

                <form method="post" action="<?= $baseURL ?>/reserva/vaciarCarrito"
                    onsubmit="return confirm('¿Estás seguro de que deseas vaciar el carrito?');">
                    <input type="hidden" name="csrf_token" value="<?= $token ?>">
                    <button type="submit" class="btn btn-danger">Vaciar Carrito</button>
                </form>
            </div>
        </div>
    <?php else: ?>
        <p class="mt-3">No hay productos en el carrito.</p>
    <?php endif; ?>
</div>

<div class="modal fade" id="modalEliminar" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <form method="post" action="<?= $baseURL ?>/reserva/quitarCantidad">
            <input type="hidden" name="csrf_token" value="<?= $token ?>">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Quitar productos del carrito</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="id_producto" id="modalIdProducto">
                    <div class="mb-3">
                        <label for="modalCantidad" class="form-label" id="labelCantidad"></label>
                        <input type="number" name="cantidad" id="modalCantidad" class="form-control" min="1" value="1">
                        <small id="stockHelp" class="form-text text-muted"></small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-danger">Quitar</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="modalWhatsapp" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">¿Deseas procesar tu reserva?</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body">
                <p>Al confirmar, se procesará tu reserva y se abrirá una nueva ventana para contactarnos por WhatsApp.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" onclick="procesarYRedirigir()">Procesar y contactar por WhatsApp</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            </div>
        </div>
    </div>
</div>

<script src="<?= $baseURL ?>/JS/JS_DE_RESERVA.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>


<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro - TODO BARRANCA</title>
    <link rel="stylesheet" href="/PROYECTO_PELUCHE/style3/Estilo_de_registro.css" />
    <script src="/PROYECTO_PELUCHE/JS/JS_DE_REGISTRO.js" defer></script>
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Crear Cuenta</h2>

        <?php if (!empty($_SESSION['registro_errores'])): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach ($_SESSION['registro_errores'] as $error): ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php endforeach; unset($_SESSION['registro_errores']); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if (!empty($_SESSION['mensaje_exito'])): ?>
            <div class="alert alert-success">
                <?= htmlspecialchars($_SESSION['mensaje_exito']); unset($_SESSION['mensaje_exito']); ?>
            </div>
        <?php endif; ?>

        <div id="erroresCliente" class="alert alert-danger" style="display: none;"></div>

        <form id="registroForm" action="/PROYECTO_PELUCHE/registro/registrar" method="POST" class="shadow p-4 rounded bg-light">
            <div class="mb-3">
                <label for="nombres" class="form-label">Nombres</label>
                <input type="text" class="form-control" id="nombres" name="nombres" placeholder="Ingrese sus nombres" required>
            </div>
            <div class="mb-3">
                <label for="apellidos" class="form-label">Apellidos</label>
                <input type="text" class="form-control" id="apellidos" name="apellidos" placeholder="Ingrese sus apellidos" required>
            </div>
            <div class="mb-3">
                <label for="telefono" class="form-label">Teléfono</label>
                <input type="text" class="form-control" id="telefono" name="telefono" placeholder="Ingrese su número de teléfono" required>
            </div>
            <div class="mb-3">
                <label for="correo" class="form-label">Correo</label>
                <input type="email" class="form-control" id="correo" name="correo" placeholder="ejemplo@email.com" required>
            </div>
            <div class="mb-3">
                <label for="contraseña" class="form-label">Contraseña</label>
                <input type="password" class="form-control" id="contraseña" name="contraseña" placeholder="Ingrese su contraseña" required maxlength="12">
            </div>
            <button type="submit" class="custom-button">Registrarse</button>
            <button type="button" onclick="window.location.href='/PROYECTO_PELUCHE/login/index'" class="custom-button">Volver al Login</button>
        </form>
    </div>
</body>
</html>

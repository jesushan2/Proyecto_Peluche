<?php require_once __DIR__ . '/../templates/header.php'; ?>

<style>
  :root {
    --rosa-claro: #f8c8dc;
    --celeste-claro: #b3d9ff;
    --turquesa-claro: #e0f7f7;
    --texto-principal: #161616;
  }

  .contacto-wrapper {
    background-color: var(--turquesa-claro);
    padding: 3rem 1rem;
  }

  .contacto-form {
    background: #fff;
    padding: 2rem;
    border-radius: 16px;
    box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
  }

  .contacto-form h2 {
    color: var(--texto-principal);
    font-weight: bold;
    margin-bottom: 1.5rem;
    border-bottom: 3px solid var(--rosa-claro);
    display: inline-block;
    padding-bottom: 6px;
  }

  .contacto-info {
    background-color: var(--celeste-claro);
    padding: 1.5rem;
    border-radius: 16px;
    margin-top: 2rem;
    border: 2px solid #000;
  }

  .contacto-info h5 {
    font-weight: bold;
    margin-bottom: 1rem;
  }

  .mapa {
    margin-top: 2rem;
    border-radius: 16px;
    overflow: hidden;
    border: 3px solid var(--rosa-claro);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
  }

  .form-control:focus {
    border-color: var(--rosa-claro);
    box-shadow: 0 0 0 0.25rem rgba(248, 200, 220, 0.25);
  }

  .btn-enviar {
    background-color: var(--rosa-claro);
    border: none;
    color: #000;
    font-weight: 600;
  }

  .btn-enviar:hover {
    background-color: #f49cb6;
  }
</style>

<div class="container contacto-wrapper">
  <div class="row justify-content-center">
    <div class="col-md-8 contacto-form">
      <h2>Contáctanos</h2>
      <form>
        <div class="mb-3">
          <label for="nombre" class="form-label">Nombre</label>
          <input type="text" class="form-control" id="nombre" placeholder="Tu nombre completo" required>
        </div>
        <div class="mb-3">
          <label for="correo" class="form-label">Correo electrónico</label>
          <input type="email" class="form-control" id="correo" placeholder="ejemplo@correo.com" required>
        </div>
        <div class="mb-3">
          <label for="asunto" class="form-label">Asunto</label>
          <input type="text" class="form-control" id="asunto" placeholder="Motivo del contacto" required>
        </div>
        <div class="mb-3">
          <label for="mensaje" class="form-label">Mensaje</label>
          <textarea class="form-control" id="mensaje" rows="5" placeholder="Escribe tu mensaje aquí..." required></textarea>
        </div>
        <button type="submit" class="btn btn-enviar">Enviar mensaje</button>
      </form>

      <div class="contacto-info mt-4">
        <h5>También puedes contactarnos directamente:</h5>
        <p><strong>Nombre:</strong> Todo Barranca</p>
        <p><strong>Correo:</strong> nezuxdead21@gmail.com</p>
        <p><strong>Teléfono:</strong> 976 115 598</p>
        <p><strong>Dirección:</strong> Calle Progreso 266, Barranca 15169</p>
        <p class="mt-3">Puede contactarnos ante cualquier queja o solicitud que desee.</p>
      </div>

      <div class="mapa mt-4">
        <iframe 
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3901.507601056207!2d-77.7525009853657!3d-10.75106016242847!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x910ac9b637e9d065%3A0xc580d9ce659c9281!2sTODO%20BARRANCA!5e0!3m2!1ses-419!2spe!4v1721153600000!5m2!1ses-419!2spe" 
          width="100%" height="350" style="border:0;" allowfullscreen="" loading="lazy"
          referrerpolicy="no-referrer-when-downgrade"></iframe>
      </div>
    </div>
  </div>
</div>
<script>
  const form = document.querySelector("form");
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    alert("Gracias por tu mensaje. Nos pondremos en contacto pronto.");
    form.reset();
  });
</script>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>

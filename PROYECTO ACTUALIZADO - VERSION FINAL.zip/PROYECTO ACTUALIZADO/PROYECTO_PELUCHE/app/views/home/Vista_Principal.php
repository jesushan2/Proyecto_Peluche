<?php require_once __DIR__ . '/../templates/header.php'; ?>


<style>
  .principal-contenido {
    --rosa-claro: #f8c8dc;
    background-color:rgb(26, 223, 223); 
    --celeste-claro:rgb(10, 80, 150);
    --texto-principal: #161616;
    background-color: #fff;
    color: var(--texto-principal);
    font-family: 'Lucida', sans-serif;
  }

  .principal-contenido .container {
    padding-top: 2rem;
    padding-bottom: 2rem;
  }

  .principal-contenido h4.text-center {
    font-weight: bold;
    color: var(--texto-principal);
    border-bottom: 3px solid var(--rosa-claro);
    display: inline-block;
    padding-bottom: 6px;
    margin-bottom: 2rem;
  }

  .principal-contenido #carouselPeluches {
    border: 4px solid var(--rosa-claro);
    border-radius: 16px;
    background-color: var(--celeste-claro);
    box-shadow: 0 6px 18px rgba(0, 0, 0, 0.15);
    overflow: hidden;
  }

  .principal-contenido .carousel-inner img {
    border-radius: 12px;
    object-fit: contain;
    background-color: white;
    padding: 10px;
    max-height: 400px;
  }

  .principal-contenido .card {
    background-color: #fefefe;
    border: 2px solid var(--celeste-claro);
    border-radius: 16px;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
  }

  .principal-contenido .card:hover {
    transform: scale(1.02);
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
  }

  .principal-contenido .card-title {
    color: #d6336c;
    font-weight: bold;
  }

  .principal-contenido .card.bg-light {
  background-color:  #d6336c; 
  border: 2px solid #000; 
  border-radius: 16px;
}


  .principal-contenido .card.bg-light .card-text {
    font-size: 0.95rem;
    color: #444;
  }

  .principal-contenido .card.bg-light .fw-bold {
    color: #d6336c;
  }

  @media (max-width: 768px) {
    .principal-contenido .carousel-inner img {
      height: 250px;
    }

    .principal-contenido .card-img-top {
      height: 200px !important;
    }
  }
</style>

<div class="principal-contenido">

 
  <div class="container mt-4">
    <h4 class="text-center mb-4">Nuestros Peluches</h4>
    <div id="carouselPeluches" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="/PROYECTO_PELUCHE/carrusel/CINNA.png" class="d-block w-100 rounded" alt="Peluche 1">
        </div>
        <div class="carousel-item">
          <img src="/PROYECTO_PELUCHE/carrusel/KITTY.png" class="d-block w-100 rounded" alt="Peluche 2">
        </div>
        <div class="carousel-item">
          <img src="/PROYECTO_PELUCHE/carrusel/KUROMI.png" class="d-block w-100 rounded" alt="Peluche 3">
        </div>
        <div class="carousel-item">
          <img src="/PROYECTO_PELUCHE/carrusel/MICKEY.png" class="d-block w-100 rounded" alt="Peluche 4">
        </div>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#carouselPeluches" data-bs-slide="prev">
        <span class="carousel-control-prev-icon"></span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselPeluches" data-bs-slide="next">
        <span class="carousel-control-next-icon"></span>
      </button>
    </div>
  </div>

  <!-- Cards destacadas -->
  <div class="container mt-5">
    <h4 class="text-center mb-4">Destacados del mes</h4>
    <div class="row g-4">
      <div class="col-md-4">
        <div class="card h-100 shadow-sm">
          <img src="/PROYECTO_PELUCHE/img/KUROMI.png" class="card-img-top" alt="Peluche 1">
          <div class="card-body">
            <h5 class="card-title">Osito Amoroso</h5>
            <p class="card-text">Perfecto para regalar en cualquier ocasión.</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card h-100 shadow-sm">
          <img src="/PROYECTO_PELUCHE/img/KITTY.png" class="card-img-top" alt="Peluche 2">
          <div class="card-body">
            <h5 class="card-title">Conejito Suave</h5>
            <p class="card-text">Un peluche que transmite ternura y calidez.</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card h-100 shadow-sm">
          <img src="/PROYECTO_PELUCHE/img/CINNA.png" class="card-img-top" alt="Peluche 3">
          <div class="card-body">
            <h5 class="card-title">Gatito Dormilón</h5>
            <p class="card-text">Ideal para abrazar antes de dormir.</p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Testimonios -->
  <div class="container mt-5 mb-5">
    <h4 class="text-center mb-4">Lo que dicen nuestros clientes</h4>
    <div class="row g-4">
      <div class="col-md-4">
        <div class="card h-100 border-0 shadow-sm bg-light">
          <div class="card-body">
            <p class="card-text fst-italic">"¡El peluche es hermoso y llegó rápido! Mi hija quedó feliz."</p>
            <p class="text-end fw-bold">- Camila R.</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card h-100 border-0 shadow-sm bg-light">
          <div class="card-body">
            <p class="card-text fst-italic">"Excelente calidad y súper suaves. Ya quiero pedir más."</p>
            <p class="text-end fw-bold">- Martín G.</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card h-100 border-0 shadow-sm bg-light">
          <div class="card-body">
            <p class="card-text fst-italic">"Atención rápida y los peluches son tal como se ven en las fotos."</p>
            <p class="text-end fw-bold">- Luisa M.</p>
          </div>
        </div>
      </div>
    </div>
  </div>

</div> 

<script>
  const myCarousel = document.querySelector('#carouselPeluches');
  const carousel = new bootstrap.Carousel(myCarousel, {
    interval: 3000,
    ride: 'carousel'
  });
</script>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>

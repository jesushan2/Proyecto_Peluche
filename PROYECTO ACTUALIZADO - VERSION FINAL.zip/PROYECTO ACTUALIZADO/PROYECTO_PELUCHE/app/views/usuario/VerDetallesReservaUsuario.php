<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Detalle de Reserva</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/PROYECTO_PELUCHE/style3/Estilo_de_header.css">
    <style>
        body {
            padding: 20px;
        }
        .producto-img {
            height: 60px;
            width: auto;
        }
    </style>
</head>
<body>


<div class="container mt-4">
    <h3>Detalle de la Reserva #<?= htmlspecialchars($reserva['id_reserva']) ?></h3>
    <p><strong>Fecha:</strong> <?= htmlspecialchars($reserva['fecha_reserva']) ?></p>
    <p><strong>Total:</strong> S/ <?= number_format($reserva['total'], 2) ?></p>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>Producto</th>
                <th>Imagen</th>
                <th>Cantidad</th>
                <th>Precio Unitario (S/)</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($productos as $prod): ?>
                <tr>
                    <td><?= htmlspecialchars($prod['nombre_prod']) ?></td>
                    <td><img src="/PROYECTO_PELUCHE/image/<?= htmlspecialchars($prod['imagen']) ?>" alt="Producto" class="producto-img"></td>
                    <td><?= $prod['cantidad'] ?></td>
                    <td><?= number_format($prod['precio_unitario'], 2) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <a href="/PROYECTO_PELUCHE/reserva/miHistorial" class="btn btn-secondary">Volver al historial</a>
</div>

</body>
</html>

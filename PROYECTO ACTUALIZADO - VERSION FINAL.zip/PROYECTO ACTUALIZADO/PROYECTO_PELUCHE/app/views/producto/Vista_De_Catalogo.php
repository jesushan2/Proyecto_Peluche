<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../templates/header.php';

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['csrf_token'];

$productosPorFranquicia = [];
foreach ($productos as $producto) {
    $franquicia = htmlspecialchars($producto['franquicia']);
    $productosPorFranquicia[$franquicia][] = $producto;
}
?>

<div class="container py-4">
    <h1 class="mb-4">Catálogo de Productos</h1>

    <input type="text" id="busqueda" placeholder="Buscar producto por nombre..." class="form-control mb-4"
        aria-label="Buscar producto" />

    <?php foreach ($productosPorFranquicia as $franquicia => $listaProductos): ?>
        <section class="franquicia-section mb-5">
            <h2 class="franquicia-title mb-3"><?= $franquicia ?></h2>

            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 g-4">
                <?php foreach ($listaProductos as $producto): ?>
                    <?php
                    $idProd = (int) $producto['id_producto'];
                    $enCarrito = isset($_SESSION['carrito'][$idProd]) ? (int) $_SESSION['carrito'][$idProd]['cantidad'] : 0;
                    $stockVisible = max(0, (int) $producto['stock'] - $enCarrito);
                    ?>
                    <div class="col producto-item" data-nombre="<?= strtolower(htmlspecialchars($producto['nombre_prod'])) ?>">
                        <div class="card h-100">
                            <img src="/PROYECTO_PELUCHE/image/<?= htmlspecialchars($producto['imagen']) ?>"
                                alt="<?= htmlspecialchars($producto['nombre_prod']) ?>" class="card-img-top producto-img"
                                style="object-fit: contain; height: 200px;" />
                            <div class="card-body d-flex flex-column">
                                <h5 class="card-title"><?= htmlspecialchars($producto['nombre_prod']) ?></h5>
                                <p class="card-text">Altura: <?= htmlspecialchars($producto['altura']) ?></p>
                                <p class="card-text">Color: <?= htmlspecialchars($producto['color']) ?></p>
                                <p class="card-text">Stock disponible: <?= $stockVisible ?></p>
                                <p class="card-text fw-bold text-success">
                                    S/ <?= number_format((float) $producto['precio'], 2) ?>
                                </p>
                                <?php if (isset($_SESSION['usuario'])): ?>
                                    <button class="btn btn-primary mt-auto" onclick="mostrarModalAgregar(
                                        <?= $idProd ?>,
                                        '<?= htmlspecialchars($producto['nombre_prod'], ENT_QUOTES) ?>',
                                        <?= $stockVisible ?>,
                                        '/PROYECTO_PELUCHE/image/<?= htmlspecialchars($producto['imagen']) ?>'
                                    )" <?= $stockVisible <= 0 ? 'disabled' : '' ?>>
                                        Reservar
                                    </button>
                                <?php else: ?>
                                    <button class="btn btn-primary mt-auto" disabled title="Inicia sesión para poder reservar">
                                        Reservar
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endforeach; ?>
</div>

<div class="modal fade" id="modalAgregar" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" action="/PROYECTO_PELUCHE/reserva/agregarCantidad">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Agregar producto al carrito</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body text-center">
                    <img id="modalImagen" src="" alt="Producto" style="max-height: 150px; object-fit: contain;" class="mb-3">
                    <p id="modalNombreProducto" class="fw-bold"></p>
                    <p id="modalStock" class="text-muted"></p>
                    <input type="hidden" name="id_producto" id="modalIdProducto">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                    <div class="mb-3">
                        <label for="modalCantidad" class="form-label">Cantidad:</label>
                        <input type="number" name="cantidad" id="modalCantidad" class="form-control" min="1" value="1" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success">Agregar</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="/PROYECTO_PELUCHE/JS/JS_DE_CATALOGO.js"></script>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>

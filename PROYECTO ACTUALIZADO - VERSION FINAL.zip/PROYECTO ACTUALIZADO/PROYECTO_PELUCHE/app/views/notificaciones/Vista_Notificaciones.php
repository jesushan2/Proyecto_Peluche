<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<?php require_once __DIR__ . '/../templates/header.php'; ?>

<div class="container mt-4">
    <h3>Mis Notificaciones</h3>

    <?php if (empty($notificaciones)): ?>
        <div class="alert alert-info">No tienes notificaciones.</div>
    <?php else: ?>
        <form method="post" action="/PROYECTO_PELUCHE/notificaciones/marcarTodasComoLeidas">
            <button type="submit" class="btn btn-success btn-sm mb-3">Marcar todas como leídas</button>
        </form>

        <ul class="list-group">
            <?php foreach ($notificaciones as $noti): ?>
                <li class="list-group-item <?= $noti['leida'] ? '' : 'list-group-item-warning' ?>">
                    <strong><?= htmlspecialchars($noti['mensaje']) ?></strong>
                    <br>
                    <small class="text-muted"><?= date("d/m/Y H:i", strtotime($noti['fecha_creacion'])) ?></small>
                    <?php if (!$noti['leida']): ?>
                        <span class="badge bg-warning text-dark ms-2">Nueva</span>
                    <?php endif; ?>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</div>


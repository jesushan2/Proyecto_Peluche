<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Login - TODO BARRANCA</title>
    <link rel="stylesheet" href="/PROYECTO_PELUCHE/style3/Estilo_de_login.css" />

    <script defer src="/PROYECTO_PELUCHE/JS/JS_DE_LOGIN.js"></script>
    <script defer src="/PROYECTO_PELUCHE/JS/googleLogin.js"></script>
    <script src="https://accounts.google.com/gsi/client" async defer></script>
</head>
<body>
<div class="login-container">
    <h2>Iniciar Sesión</h2>

    <?php if (!empty($_SESSION['error_login'])): ?>
        <div class="error-box"><?= htmlspecialchars($_SESSION['error_login']) ?></div>
        <?php unset($_SESSION['error_login']); ?>
    <?php endif; ?>

    <form id="loginForm" action="/PROYECTO_PELUCHE/login/login" method="POST" novalidate>
        <label for="correo">Correo:</label>
        <input type="email" name="correo" id="correo" required placeholder="Ejemplo@correo.com" />
        
        <label for="contraseña">Contraseña:</label>
        <input type="password" name="contraseña" id="contraseña" required maxlength="12" />

        <div class="button-group">
            <button type="submit">Ingresar</button>
            <button type="button" onclick="window.location.href='/PROYECTO_PELUCHE/registro/index'">Registrar</button>
        </div>
    </form>

    <div class="text-center mt-4">
    <div id="g_id_onload"
     data-client_id="60524499120-5vbfhsdffoe2jigkkrsqi7kq2vp2sjan.apps.googleusercontent.com"
     data-callback="handleCredentialResponse"
     data-auto_prompt="false">
</div>
<div class="g_id_signin" data-type="standard" data-size="large" data-theme="outline"></div>
    </div>
</div>
</body>
</html>

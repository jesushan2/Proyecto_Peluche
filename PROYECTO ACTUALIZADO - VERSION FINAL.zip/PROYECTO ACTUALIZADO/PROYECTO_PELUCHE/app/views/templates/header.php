<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../../models/DAOnotificaciones.php';

$contadorCarrito = 0;
if (!empty($_SESSION['carrito']) && is_array($_SESSION['carrito'])) {
    foreach ($_SESSION['carrito'] as $item) {
        $cantidad = isset($item['cantidad']) ? (int) $item['cantidad'] : 0;
        $contadorCarrito += $cantidad > 0 ? $cantidad : 0;
    }
}
$contadorNotificaciones = 0;
if (isset($_SESSION['usuario'])) {
    $daoNotificaciones = new DAOnotificaciones();
    $idUsuario = $_SESSION['usuario']['id_usuario'] ?? null;
    if ($idUsuario) {
        $contadorNotificaciones = $daoNotificaciones->contarNoLeidasPorUsuario((int) $idUsuario);
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>TODO BARRANCA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />
    <link rel="stylesheet" href="/PROYECTO_PELUCHE/style3/Estilo_de_header.css" />
</head>

<body>
    <nav class="navbar navbar-expand-lg bg-light shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="/PROYECTO_PELUCHE/home/index">
                <img src="/PROYECTO_PELUCHE/image/logo.png" alt="Logo TODO BARRANCA" style="height: 40px;" />
                TODO BARRANCA
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link" href="/PROYECTO_PELUCHE/home/index">Inicio</a></li>
                    <li class="nav-item"><a class="nav-link" href="/PROYECTO_PELUCHE/producto/catalogo">Catálogo</a>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="/PROYECTO_PELUCHE/home/contacto">Contacto</a></li>
                </ul>

                <ul class="navbar-nav ms-auto nav-user-area">
                    <li class="nav-item position-relative">
                        <a class="nav-link carrito-icono" href="/PROYECTO_PELUCHE/reserva/verCarrito"
                            title="Ver carrito">
                            <i class="bi bi-cart3"></i>
                            <span class="contador-carrito"><?= htmlspecialchars($contadorCarrito) ?></span>
                        </a>
                    </li>
                    <li class="nav-item position-relative">
                        <a class="nav-link" href="/PROYECTO_PELUCHE/notificaciones/ver" title="Notificaciones">
                            <i class="bi bi-bell"></i>
                            <?php if ($contadorNotificaciones > 0): ?>
                                <span
                                    class="badge bg-danger rounded-pill position-absolute top-0 start-100 translate-middle">
                                    <?= $contadorNotificaciones ?>
                                </span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <?php if (isset($_SESSION['usuario'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/PROYECTO_PELUCHE/reserva/miHistorial">Mi Historial</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">
                                Hola, <?= htmlspecialchars($_SESSION['usuario']['nombres'] ?? 'Usuario') ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/PROYECTO_PELUCHE/login/logout">Cerrar sesión</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/PROYECTO_PELUCHE/login/index">Iniciar sesión</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
<footer style="background-color: #b3d9ff; font-family: 'Times New Roman', serif; color: #000;">
  <div class="container py-4">
    <div class="row text-center text-md-start">
      <div class="col-md-6 mb-3">
        <h5 class="fw-bold">Todo Barranca</h5>
        <p class="mb-1">Dirección: Calle Progreso 266, Barranca 15169</p>
        <p class="mb-1">Correo: nezuxdead21@gmail.com</p>
        <p>Teléfono: 976 115 598</p>
      </div>
      <div class="col-md-6 text-md-end">
        <p class="mb-1">&copy; <?php echo date("Y"); ?> Todo Barranca. Todos los derechos reservados.</p>
        <p class="mb-0">Hecho con ❤️ en Perú</p>
      </div>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

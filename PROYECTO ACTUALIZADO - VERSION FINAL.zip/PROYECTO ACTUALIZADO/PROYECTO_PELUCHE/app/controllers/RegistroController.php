<?php
class RegistroController {
    private $modelo;
    private $modoTest = false;

    public function __construct($modelo = null) {
        require_once __DIR__ . '/../../config/database.php';
        require_once __DIR__ . '/../models/DAOregistro.php';
        require_once __DIR__ . '/../models/LoggerWeb.php';

        $this->modelo = $modelo ?? new DAOregistro(Database::connect());

        if (session_status() === PHP_SESSION_NONE) session_start();
    }

    public function activarModoTest() {
        $this->modoTest = true;
    }

    public function index() {
        if (!$this->modoTest) {
            require_once __DIR__ . '/../views/registro/Vista_De_Registro.php';
        }
    }

    public function registrar() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombres    = trim($_POST['nombres'] ?? '');
            $apellidos  = trim($_POST['apellidos'] ?? '');
            $telefono   = trim($_POST['telefono'] ?? '');
            $correo     = trim($_POST['correo'] ?? '');
            $contraseña = $_POST['contraseña'] ?? '';
            $fecha      = date('Y-m-d H:i:s');
            $activo     = 1;

            $errores = [];

            if (!preg_match("/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]{2,50}$/", $nombres)) $errores[] = "Nombre inválido.";
            if (!preg_match("/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]{2,50}$/", $apellidos)) $errores[] = "Apellido inválido.";
            if (!preg_match("/^[0-9]{9}$/", $telefono)) $errores[] = "Teléfono inválido.";
            if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) $errores[] = "Correo inválido.";
            if (strlen($contraseña) < 4 || strlen($contraseña) > 12) $errores[] = "Contraseña entre 4 y 12 caracteres.";

            $logger = new LoggerWeb();

            if ($this->modelo->correoExiste($correo)) {
                $errores[] = "Este correo ya está en uso. Prueba otro.";
            }

            if (!empty($errores)) {
                $_SESSION['registro_errores'] = $errores;
                $logger->registrar(null, 'registro_fallido', "Intento fallido de registro para correo: $correo");

                if (!$this->modoTest) {
                    header("Location: /PROYECTO_PELUCHE/registro/index");
                    exit;
                }
                return;
            }

            $hash = password_hash($contraseña, PASSWORD_BCRYPT);

            if ($this->modelo->insertarUsuario($nombres, $apellidos, $telefono, $correo, $hash, $fecha, $activo)) {
                $_SESSION['mensaje_exito'] = "¡Cuenta registrada correctamente!";
                $nuevo = $this->modelo->obtenerUsuarioPorCorreo($correo);
                $logger->registrar($nuevo['id_usuario'] ?? null, 'registro_exitoso', "Registro exitoso: $correo");
            } else {
                $_SESSION['registro_errores'] = ["❌ Error al registrar. Intenta más tarde."];
                $logger->registrar(null, 'registro_error', "Fallo técnico al insertar usuario: $correo");
            }

            if (!$this->modoTest) {
                header("Location: /PROYECTO_PELUCHE/login/index");
                exit;
            }
        }
    }
}

<?php

class HomeController {

    public function index() {
        require_once __DIR__ . '/../models/LoggerWeb.php';
        $logger = new LoggerWeb();
        $idUsuario = $_SESSION['usuario']['id_usuario'] ?? null;
        $logger->registrar($idUsuario, 'vista_home', 'Acceso público a la página principal');

        require_once __DIR__ . '/../views/home/Vista_Principal.php';
    }

    public function contacto() {
        require_once __DIR__ . '/../models/LoggerWeb.php';
        $logger = new LoggerWeb();
        $idUsuario = $_SESSION['usuario']['id_usuario'] ?? null;
        $logger->registrar($idUsuario, 'vista_contacto', 'Acceso público a contacto');

        require_once __DIR__ . '/../views/home/contacto.php';
    }
}

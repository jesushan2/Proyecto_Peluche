<?php
require_once __DIR__ . '/../models/DAOproducto.php';
require_once __DIR__ . '/../models/LoggerWeb.php';

class ProductoController {
    private $modoTest = false;
    private $daoProducto;
    private $logger;

    public function __construct($daoProducto = null, $logger = null) {
        $this->daoProducto = $daoProducto ?? new DAOproducto();
        $this->logger = $logger ?? new LoggerWeb();
        if (session_status() === PHP_SESSION_NONE) session_start();
    }

    public function activarModoTest() {
        $this->modoTest = true;
    }

    public function catalogo() {
        $usuarioId = $_SESSION['usuario']['id_usuario'] ?? null;
        $this->logger->registrar($usuarioId, 'vista_catalogo', 'Acceso al catálogo de productos');

        $productos = $this->daoProducto->obtenerProductosConFranquicia();
        if (!is_array($productos)) $productos = [];

        if ($this->modoTest) {
            return $productos; 
        }

        require_once __DIR__ . '/../views/producto/Vista_De_Catalogo.php';
    }
}

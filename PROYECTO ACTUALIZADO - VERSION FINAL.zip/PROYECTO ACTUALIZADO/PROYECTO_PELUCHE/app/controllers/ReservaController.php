<?php
require_once __DIR__ . '/../models/DAOreserva.php';
require_once __DIR__ . '/../models/LoggerWeb.php';

class ReservaController
{
    private DAOreserva $modelo;

    public function __construct()
    {
        if (session_status() === PHP_SESSION_NONE) session_start();

        if (!isset($_SESSION['usuario'])) {
            header("Location: /PROYECTO_PELUCHE/login/index");
            exit;
        }

        if (!isset($_SESSION['carrito'])) $_SESSION['carrito'] = [];

        $this->modelo = new DAOreserva();
    }

    public function verDetalleUsuario() {
        if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
            die("Reserva inválida.");
        }
    
        $idReserva = (int) $_GET['id'];

        if (!isset($_SESSION['usuario']['id_usuario'])) {
            header("Location: /PROYECTO_PELUCHE/login/index");
            exit;
        }
    
        $usuarioId = $_SESSION['usuario']['id_usuario'];
        $dao = new DAOreserva();
        
        $reserva = $dao->obtenerReservaPorIdYUsuario($idReserva, $usuarioId);
        if (!$reserva) {
            die("Reserva no encontrada o no pertenece al usuario.");
        }
    
        $productos = $dao->obtenerDetallesReserva($idReserva);
        require_once __DIR__ . '/../views/usuario/VerDetallesReservaUsuario.php';
    }
    
    public function miHistorial() {
        if (!isset($_SESSION['usuario']['id_usuario'])) {
            header("Location: /PROYECTO_PELUCHE/login/index");
            exit;
        }
    
        $idUsuario = $_SESSION['usuario']['id_usuario'];
    
        require_once __DIR__ . '/../models/DAOreserva.php';
        $dao = new DAOreserva();
        $historial = $dao->obtenerReservasPorUsuario($idUsuario);
    
        require_once __DIR__ . '/../views/reserva/HistorialReservasUsuario.php';
    }
    
    public function index()
    {
        $this->verCarrito();
    }

    public function verCarrito()
    {
        require_once __DIR__ . '/../views/reserva/Vista_De_Carrito.php';
    }

    public function agregar()
    {
        $id = intval($_GET['id'] ?? 0);
        $this->intentarAgregarProducto($id, 1);
    }

    public function agregarCantidad()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!$this->validarCsrfToken($_POST['csrf_token'] ?? '')) {
                die("Token CSRF inválido");
            }

            $id = intval($_POST['id_producto'] ?? 0);
            $cantidad = intval($_POST['cantidad'] ?? 1);
            $this->intentarAgregarProducto($id, $cantidad);
        }
    }

    private function intentarAgregarProducto(int $idProducto, int $cantidad): void
    {
        $logger = new LoggerWeb();
        $id_usuario = $_SESSION['usuario']['id_usuario'] ?? null;

        if ($cantidad < 1) {
            $logger->registrar($id_usuario, 'carrito_error', "Cantidad inválida: $cantidad para producto $idProducto");
            $this->redirigirConMensaje('error', "Cantidad inválida.", 'producto', 'catalogo');
        }

        $producto = $this->modelo->obtenerProductoPorId($idProducto);
        if (!$producto) {
            $logger->registrar($id_usuario, 'carrito_error', "Producto no encontrado: $idProducto");
            $this->redirigirConMensaje('error', "Producto no encontrado.", 'producto', 'catalogo');
        }

        $stockDisponible = $this->modelo->obtenerStockProducto($idProducto);
        $enCarrito = $this->obtenerCantidadEnCarrito($idProducto);

        if ($stockDisponible < $cantidad + $enCarrito) {
            $logger->registrar($id_usuario, 'carrito_error', "Sin stock para producto $idProducto");
            $this->redirigirConMensaje('error', "Stock insuficiente.", 'producto', 'catalogo');
        }

        $this->agregarAlCarrito($producto, $cantidad);
        $logger->registrar($id_usuario, 'carrito_agregado', "Producto $idProducto agregado ($cantidad unidades)");
        $this->redirigirConMensaje('mensaje', "Producto agregado al carrito.", 'producto', 'catalogo');
    }

    private function obtenerCantidadEnCarrito(int $id): int
    {
        return $_SESSION['carrito'][$id]['cantidad'] ?? 0;
    }

    private function agregarAlCarrito(array $producto, int $cantidad): void
    {
        $id = (int)$producto['id_producto'];

        if (isset($_SESSION['carrito'][$id])) {
            $_SESSION['carrito'][$id]['cantidad'] += $cantidad;
        } else {
            $_SESSION['carrito'][$id] = [
                'id_producto' => $id,
                'nombre'     => htmlspecialchars($producto['nombre_prod']),
                'precio'     => (float)$producto['precio'],
                'imagen'     => htmlspecialchars($producto['imagen']),
                'cantidad'   => $cantidad
            ];
        }
    }

    private function redirigirConMensaje(string $tipo, string $mensaje, string $controller, string $action): void
    {
        $_SESSION[$tipo] = $mensaje;
        header("Location: /PROYECTO_PELUCHE/$controller/$action");
        exit;
    }

    public function eliminar()
    {
        $id = intval($_GET['id'] ?? 0);
        $id_usuario = $_SESSION['usuario']['id_usuario'] ?? null;
        $logger = new LoggerWeb();

        if (isset($_SESSION['carrito'][$id])) {
            unset($_SESSION['carrito'][$id]);
            $_SESSION['mensaje'] = "Producto eliminado del carrito.";
            $logger->registrar($id_usuario, 'carrito_modificado', "Producto $id eliminado del carrito");
        } else {
            $_SESSION['error'] = "Producto no encontrado.";
            $logger->registrar($id_usuario, 'carrito_error', "Intento eliminar producto no existente: $id");
        }

        header('Location: /PROYECTO_PELUCHE/reserva/verCarrito');
        exit;
    }

    public function quitarCantidad()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!$this->validarCsrfToken($_POST['csrf_token'] ?? '')) {
                die("Token CSRF inválido");
            }

            $id = intval($_POST['id_producto'] ?? 0);
            $cantidad = intval($_POST['cantidad'] ?? 0);
            $logger = new LoggerWeb();
            $id_usuario = $_SESSION['usuario']['id_usuario'] ?? null;

            if (isset($_SESSION['carrito'][$id])) {
                $actual = $_SESSION['carrito'][$id]['cantidad'];

                if ($cantidad >= $actual) {
                    unset($_SESSION['carrito'][$id]);
                    $_SESSION['mensaje'] = "Producto eliminado completamente.";
                    $logger->registrar($id_usuario, 'carrito_modificado', "Producto $id eliminado completamente");
                } elseif ($cantidad > 0) {
                    $_SESSION['carrito'][$id]['cantidad'] -= $cantidad;
                    $_SESSION['mensaje'] = "Se quitaron $cantidad unidades.";
                    $logger->registrar($id_usuario, 'carrito_modificado', "Quitadas $cantidad unidades de producto $id");
                } else {
                    $_SESSION['error'] = "Cantidad inválida.";
                    $logger->registrar($id_usuario, 'carrito_error', "Cantidad inválida: $cantidad");
                }
            }
        }
        header('Location: /PROYECTO_PELUCHE/reserva/verCarrito');
        exit;
    }

    public function procesarReserva()
    {
        $logger = new LoggerWeb();

        if (empty($_SESSION['carrito'])) {
            $logger->registrar($_SESSION['usuario']['id_usuario'], 'carrito_vacio', "Reserva sin productos");
            $this->redirigirConMensaje('error', "El carrito está vacío.", 'reserva', 'verCarrito');
        }

        try {
            $this->modelo->conexion->beginTransaction();
            $id_usuario = (int)$_SESSION['usuario']['id_usuario'];
            $id_estado = 1;
            $total = array_reduce($_SESSION['carrito'], fn($sum, $item) => $sum + ($item['precio'] * $item['cantidad']), 0);
            $id_reserva = $this->modelo->insertarReserva($id_usuario, $id_estado, $total);

            foreach ($_SESSION['carrito'] as $item) {
                $stock = $this->modelo->obtenerStockProducto($item['id_producto']);
                if ($stock < $item['cantidad']) {
                    unset($_SESSION['carrito'][$item['id_producto']]);
                    $_SESSION['error'] = "Stock insuficiente para '{$item['nombre']}'. Eliminado del carrito.";
                    $this->modelo->conexion->rollBack();
                    $logger->registrar($id_usuario, 'reserva_fallida', "Sin stock para {$item['id_producto']}");
                    header('Location: /PROYECTO_PELUCHE/reserva/verCarrito');
                    exit;
                }

                $this->modelo->insertarDetalleReserva($id_reserva, $item['id_producto'], $item['cantidad'], $item['precio']);
                $this->modelo->actualizarStockProducto($item['id_producto'], $item['cantidad']);
            }

            $this->modelo->conexion->commit();
            $_SESSION['carrito'] = [];
            $_SESSION['mensaje'] = "Reserva procesada con éxito.";
            $logger->registrar($id_usuario, 'reserva_exitosa', "Reserva #$id_reserva completada");
        } catch (Exception $e) {
            $this->modelo->conexion->rollBack();
            $_SESSION['error'] = "Error al procesar reserva: " . $e->getMessage();
            $logger->registrar($id_usuario, 'reserva_fallida', "Error: {$e->getMessage()}");
        }

        header('Location: /PROYECTO_PELUCHE/reserva/verCarrito');
        exit;
    }

    public function vaciarCarrito()
    {
        $id_usuario = $_SESSION['usuario']['id_usuario'] ?? null;
        $_SESSION['carrito'] = [];
        $_SESSION['mensaje'] = "Carrito vaciado.";

        $logger = new LoggerWeb();
        $logger->registrar($id_usuario, 'carrito_vaciado', "Carrito vaciado manualmente");
        header('Location: /PROYECTO_PELUCHE/reserva/verCarrito');
        exit;
    }


    public static function generarCsrfToken(): string
    {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        return $_SESSION['csrf_token'];
    }

    private function validarCsrfToken(string $token): bool
    {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }
}

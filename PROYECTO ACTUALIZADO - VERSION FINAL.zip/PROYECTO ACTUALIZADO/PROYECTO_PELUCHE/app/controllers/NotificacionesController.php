<?php
require_once __DIR__ . '/../models/DAOnotificaciones.php';

class NotificacionesController {
    private DAOnotificaciones $dao;

    public function __construct() {
        $this->dao = new DAOnotificaciones();
        if (session_status() === PHP_SESSION_NONE) session_start();
    }

    public function verNotificaciones() {
        if (!isset($_SESSION['usuario'])) {
            header("Location: /PROYECTO_PELUCHE/login/index");
            exit;
        }

        $idUsuario = $_SESSION['usuario']['id_usuario'];
        $notificaciones = $this->dao->obtenerNotificacionesPorUsuario($idUsuario);

        require_once __DIR__ . '/../views/notificaciones/Vista_Notificaciones.php';
    }
    public function ver() {
        if (!isset($_SESSION['usuario'])) {
            header("Location: /PROYECTO_PELUCHE/login/index");
            exit;
        }
    
        $idUsuario = $_SESSION['usuario']['id_usuario'];
        $dao = new DAOnotificaciones();
        $notificaciones = $dao->obtenerNotificacionesPorUsuario($idUsuario);
    
        require_once __DIR__ . '/../views/notificaciones/Vista_Notificaciones.php';
    }
    public function marcarTodasComoLeidas() {
        if (!isset($_SESSION['usuario'])) {
            header("Location: /PROYECTO_PELUCHE/login/index");
            exit;
        }

        $idUsuario = $_SESSION['usuario']['id_usuario'];
        $this->dao->marcarComoLeidas($idUsuario);

        header("Location: /PROYECTO_PELUCHE/notificaciones/ver");
        exit;
    }
}

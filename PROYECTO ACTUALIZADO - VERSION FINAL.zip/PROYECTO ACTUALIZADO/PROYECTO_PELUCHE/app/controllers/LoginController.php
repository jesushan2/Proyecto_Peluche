<?php
class LoginController {
    private $conexion;
    private $modoTest = false;

    public function activarModoTest() {
        $this->modoTest = true;
    }

    public function __construct() {
        require_once __DIR__ . '/../../config/database.php';
        require_once __DIR__ . '/../models/DAOlogin.php';
        require_once __DIR__ . '/../models/DAOregistro.php';
        require_once __DIR__ . '/../models/LoggerWeb.php';

        $this->conexion = Database::connect();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    public function index() {
        $logger = new LoggerWeb();
        $logger->registrar(null, 'vista_login', 'Ingreso a la página de login');
        require_once __DIR__ . '/../views/login/Vista_Del_Login.php';
    }

    public function googleLogin() {
        header('Content-Type: application/json');

        $logger = new LoggerWeb();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $credential = $_POST['credential'] ?? null;

            if (!$credential) {
                $logger->registrar(null, 'google_login_error', 'Token no recibido');
                echo json_encode(['success' => false, 'message' => 'Token no recibido']);
                return;
            }

            $url = "https://oauth2.googleapis.com/tokeninfo?id_token=" . urlencode($credential);
            $response = @file_get_contents($url);

            if (!$response) {
                $logger->registrar(null, 'google_login_error', 'Error verificando token');
                echo json_encode(['success' => false, 'message' => 'No se pudo verificar el token con Google']);
                return;
            }

            $datos = json_decode($response, true);

            if (!isset($datos['email']) || !filter_var($datos['email'], FILTER_VALIDATE_EMAIL)) {
                $logger->registrar(null, 'google_login_error', 'Token inválido o sin correo');
                echo json_encode(['success' => false, 'message' => 'Token inválido o sin correo']);
                return;
            }

            $correo = $datos['email'];
            $nombre = substr($datos['given_name'] ?? '', 0, 50);
            $apellido = substr($datos['family_name'] ?? '', 0, 50);

            $usuario = DAOlogin::ObtenerPorCorreo($this->conexion, $correo);

            if (!$usuario) {
                $registro = new DAOregistro($this->conexion);
                $clave = password_hash(bin2hex(random_bytes(6)), PASSWORD_BCRYPT);
                $registro->insertarUsuario($nombre, $apellido, '', $correo, $clave, date('Y-m-d H:i:s'), 1);
                $usuario = DAOlogin::ObtenerPorCorreo($this->conexion, $correo);
            }

            if (!$usuario) {
                $logger->registrar(null, 'google_login_error', 'No se pudo crear el usuario');
                echo json_encode(['success' => false, 'message' => 'Error creando el usuario']);
                return;
            }

            $_SESSION['usuario'] = $usuario;

            $logger->registrar($usuario['id_usuario'], 'login_google', 'Inicio de sesión con Google');
            echo json_encode(['success' => true]);
            return;
        }

        $logger->registrar(null, 'google_login_error', 'Acceso no permitido');
        echo json_encode(['success' => false, 'message' => 'Acceso no permitido']);
    }

    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $correo = isset($_POST['correo']) ? filter_var($_POST['correo'], FILTER_SANITIZE_EMAIL) : '';
            $contraseña = $_POST['contraseña'] ?? '';
   
            

            $logger = new LoggerWeb();

            if (!filter_var($correo, FILTER_VALIDATE_EMAIL) || strlen($contraseña) < 4 || strlen($contraseña) > 50) {
                $_SESSION['error_login'] = "Datos inválidos.";
                $logger->registrar(null, 'login_datos_invalidos', "Entrada inválida: $correo");
                if (!$this->modoTest) {
                    header("Location: /PROYECTO_PELUCHE/login/index");
                    exit;
                }
                return;
            }

            if (!isset($_SESSION['intentos_login'])) {
                $_SESSION['intentos_login'] = 0;
                $_SESSION['bloqueado_hasta'] = null;
            }

            if ($_SESSION['bloqueado_hasta'] && time() < $_SESSION['bloqueado_hasta']) {
                $_SESSION['error_login'] = "Demasiados intentos fallidos. Intenta nuevamente en 5 minutos.";
                $logger->registrar(null, 'login_bloqueado', "Login bloqueado para: $correo");
                if (!$this->modoTest) {
                    header("Location: /PROYECTO_PELUCHE/login/index");
                    exit;
                }
                return;
            }

            $usuario = DAOlogin::ObtenerPorCorreo($this->conexion, $correo);

            if ($usuario && password_verify($contraseña, $usuario['contraseña'])) {
                $_SESSION['usuario'] = $usuario;
                $_SESSION['intentos_login'] = 0;
                $_SESSION['bloqueado_hasta'] = null;

                $logger->registrar($usuario['id_usuario'], 'login_exitoso', 'Inicio de sesión exitoso');
                if (!$this->modoTest) {
                    header("Location: /PROYECTO_PELUCHE/home/index");
                    exit;
                }
                return;
            } else {
                $_SESSION['intentos_login']++;

                $logger->registrar(null, 'login_fallido', "Intento fallido con: $correo");

                if ($_SESSION['intentos_login'] >= 3) {
                    $_SESSION['bloqueado_hasta'] = time() + (5 * 60);
                    $_SESSION['error_login'] = "Has superado los 3 intentos. Intenta nuevamente en 5 minutos.";
                    $logger->registrar(null, 'login_bloqueado_iniciado', "Bloqueo por 5 minutos: $correo");
                } else {
                    $_SESSION['error_login'] = "Correo o contraseña incorrectos.";
                }

                if (!$this->modoTest) {
                    header("Location: /PROYECTO_PELUCHE/login/index");
                    exit;
                }
                return;
            }
        }

        $this->index();
    }

    public function logout() {
        $idUsuario = $_SESSION['usuario']['id_usuario'] ?? null;

        $logger = new LoggerWeb();
        $logger->registrar($idUsuario, 'logout', 'Usuario cerró sesión.');

        if ($this->modoTest) {
            $_SESSION = [];
        } else {
            session_destroy();
            header("Location: /PROYECTO_PELUCHE/login/index");
            exit();
        }
    }
}

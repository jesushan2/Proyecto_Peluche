<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/LoggerWeb.php';

class DAOreserva {
    public PDO $conexion;

    public function __construct() {
        $this->conexion = Database::connect();
    }

    public function obtenerProductoPorId(int $idProducto): ?array {
        try {
            $stmt = $this->conexion->prepare("SELECT id_producto, nombre_prod, precio, imagen FROM productos WHERE id_producto = :id");
            $stmt->bindParam(':id', $idProducto, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
        } catch (PDOException $e) {
            $this->logError('obtenerProductoPorId', $e->getMessage());
            return null;
        }
    }

    public function obtenerReservasPorUsuario(int $idUsuario): array {
        try {
            $sql = "SELECT id_reserva, fecha_reserva, total 
                    FROM reservas 
                    WHERE id_usuario = :id AND estado_activo = 1 
                    ORDER BY fecha_reserva DESC";
    
            $stmt = $this->conexion->prepare($sql);
            $stmt->bindParam(':id', $idUsuario, PDO::PARAM_INT);
            $stmt->execute();
    
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $this->logError('obtenerReservasPorUsuario', $e->getMessage());
            return [];
        }
    }
    public function obtenerReservaPorIdYUsuario(int $idReserva, int $idUsuario): ?array {
        try {
            $sql = "SELECT * FROM reservas WHERE id_reserva = :id AND id_usuario = :usuario_id";
            $stmt = $this->conexion->prepare($sql);
            $stmt->bindParam(':id', $idReserva, PDO::PARAM_INT);
            $stmt->bindParam(':usuario_id', $idUsuario, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
        } catch (PDOException $e) {
            $this->logError('obtenerReservaPorIdYUsuario', $e->getMessage());
            return null;
        }
    }
    
    public function obtenerDetallesReserva(int $idReserva): array {
        try {
            $sql = "SELECT p.nombre_prod, p.imagen, dr.cantidad, dr.precio_unitario
                    FROM detalles_reserva dr
                    INNER JOIN productos p ON dr.id_producto = p.id_producto
                    WHERE dr.id_reserva = :id";
            $stmt = $this->conexion->prepare($sql);
            $stmt->bindParam(':id', $idReserva, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $this->logError('obtenerDetallesReserva', $e->getMessage());
            return [];
        }
    }
    
    
    public function obtenerStockProducto(int $idProducto): int {
        try {
            $stmt = $this->conexion->prepare("SELECT stock FROM productos WHERE id_producto = ?");
            $stmt->execute([$idProducto]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row ? (int)$row['stock'] : 0;
        } catch (PDOException $e) {
            $this->logError('obtenerStockProducto', $e->getMessage());
            return 0;
        }
    }

    public function insertarReserva(int $idUsuario, int $idEstado, float $total): int {
        try {
            $stmt = $this->conexion->prepare("INSERT INTO reservas (id_usuario, id_estado, total) VALUES (?, ?, ?)");
            $stmt->execute([$idUsuario, $idEstado, $total]);
            return (int)$this->conexion->lastInsertId();
        } catch (PDOException $e) {
            $this->logError('insertarReserva', $e->getMessage());
            return 0;
        }
    }

    public function insertarDetalleReserva(int $idReserva, int $idProducto, int $cantidad, float $precioUnitario): void {
        try {
            $stmt = $this->conexion->prepare("INSERT INTO detalles_reserva (id_reserva, id_producto, cantidad, precio_unitario) VALUES (?, ?, ?, ?)");
            $stmt->execute([$idReserva, $idProducto, $cantidad, $precioUnitario]);
        } catch (PDOException $e) {
            $this->logError('insertarDetalleReserva', $e->getMessage());
        }
    }

    public function actualizarStockProducto(int $idProducto, int $cantidad): void {
        try {
            $stmt = $this->conexion->prepare("UPDATE productos SET stock = stock - ? WHERE id_producto = ?");
            $stmt->execute([$cantidad, $idProducto]);
        } catch (PDOException $e) {
            $this->logError('actualizarStockProducto', $e->getMessage());
        }
    }

    private function logError(string $metodo, string $mensaje): void {
        $logger = new LoggerWeb();
        $id_usuario = $_SESSION['usuario']['id_usuario'] ?? null;
        $logger->registrar($id_usuario, 'dao_error', "DAOreserva->$metodo: $mensaje");
    }
}

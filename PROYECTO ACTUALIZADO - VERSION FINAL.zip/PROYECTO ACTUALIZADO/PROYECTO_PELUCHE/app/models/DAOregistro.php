<?php
require_once __DIR__ . '/LoggerWeb.php';

class DAOregistro {
    private PDO $conexion;

    public function __construct(PDO $conexion) {
        $this->conexion = $conexion;
    }

    public function correoExiste(string $correo): bool {
        try {
            $stmt = $this->conexion->prepare("SELECT COUNT(*) FROM usuarios WHERE correo = ?");
            $stmt->execute([$correo]);
            return $stmt->fetchColumn() > 0;
        } catch (PDOException $e) {
            $this->logError('correoExiste', $e->getMessage());
            return false;
        }
    }

    public function insertarUsuario(string $nombres, string $apellidos, string $telefono, string $correo, string $contraseña, string $fecha, int $activo): bool {
        try {
            $stmt = $this->conexion->prepare("CALL sp_registrar_usuario(?, ?, ?, ?, ?, ?, ?)");
            return $stmt->execute([$nombres, $apellidos, $telefono, $correo, $contraseña, $fecha, $activo]);
        } catch (PDOException $e) {
            $this->logError('insertarUsuario', $e->getMessage());
            return false;
        }
    }

    public function obtenerUsuarioPorCorreo(string $correo): ?array {
        try {
            $stmt = $this->conexion->prepare("SELECT * FROM usuarios WHERE correo = ?");
            $stmt->execute([$correo]);
            return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
        } catch (PDOException $e) {
            $this->logError('obtenerUsuarioPorCorreo', $e->getMessage());
            return null;
        }
    }

    private function logError(string $metodo, string $mensaje): void {
        $logger = new LoggerWeb();
        $id_usuario = $_SESSION['usuario']['id_usuario'] ?? null;
        $logger->registrar($id_usuario, 'dao_error', "DAOregistro->$metodo: $mensaje");
    }
}

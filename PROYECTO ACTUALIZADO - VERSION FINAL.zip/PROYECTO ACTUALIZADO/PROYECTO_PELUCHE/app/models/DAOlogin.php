<?php
require_once __DIR__ . '/LoggerWeb.php';

class DAOlogin {

    public static function ObtenerPorCorreo(PDO $conexion, string $correo): ?array {
        try {
            $stmt = $conexion->prepare("SELECT * FROM usuarios WHERE correo = :correo AND estado_activo = 1");
            $stmt->bindParam(':correo', $correo, PDO::PARAM_STR);
            $stmt->execute();

            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
            return $usuario !== false ? $usuario : null;

        } catch (PDOException $e) {
            $logger = new LoggerWeb();
            $id_usuario = $_SESSION['usuario']['id_usuario'] ?? null;
            $logger->registrar($id_usuario, 'dao_error', "DAOlogin->ObtenerPorCorreo: " . $e->getMessage());

            return null;
        }
    }
}

<?php
require_once __DIR__ . '/../../config/database.php';

class LoggerWeb {
    private PDO $conexion;

    public function __construct() {
        try {
            $this->conexion = Database::connect();
        } catch (PDOException $e) {
        }
    }

    public function registrar(?int $idUsuario, string $accion, string $descripcion = null): bool {
        try {
            if (!$this->conexion) {
                return false;
            }

            $ip = $_SERVER['REMOTE_ADDR'] ?? 'Desconocido';
            $userAgent = substr($_SERVER['HTTP_USER_AGENT'] ?? 'Desconocido', 0, 255);
            $descripcion = substr($descripcion ?? '', 0, 500); // por si es muy largo

            $stmt = $this->conexion->prepare("
                INSERT INTO logs_web (id_usuario, accion, descripcion, ip_usuario, user_agent)
                VALUES (:id_usuario, :accion, :descripcion, :ip_usuario, :user_agent)
            ");

            return $stmt->execute([
                ':id_usuario' => $idUsuario,
                ':accion' => $accion,
                ':descripcion' => $descripcion,
                ':ip_usuario' => $ip,
                ':user_agent' => $userAgent
            ]);
        } catch (PDOException $e) {
            return false;
        }
    }
}

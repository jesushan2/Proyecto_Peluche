<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/LoggerWeb.php';

class DAOproducto {
    private PDO $db;

    public function __construct() {
        $this->db = Database::connect();
    }

    public function obtenerProductosConFranquicia(): array {
        try {
            $sql = "SELECT p.*, f.nombre_fran AS franquicia
                    FROM productos p
                    INNER JOIN franquicias f ON p.id_franquicia = f.id_franquicia
                    ORDER BY f.nombre_fran ASC, p.nombre_prod ASC";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

        } catch (PDOException $e) {
            // Loguear el error
            $logger = new LoggerWeb();
            $id_usuario = $_SESSION['usuario']['id_usuario'] ?? null;
            $logger->registrar($id_usuario, 'dao_error', 'DAOproducto->obtenerProductosConFranquicia: ' . $e->getMessage());
            
            return [];
        }
    }
}

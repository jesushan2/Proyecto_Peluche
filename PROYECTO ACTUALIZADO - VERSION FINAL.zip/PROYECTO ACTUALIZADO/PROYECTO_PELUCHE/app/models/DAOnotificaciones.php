<?php
require_once __DIR__ . '/../../config/database.php';

class DAOnotificaciones {
    private $conexion;

    public function __construct() {
        $this->conexion = Database::connect();
    }

    // 1. Contar notificaciones no leídas del usuario
    public function contarNoLeidasPorUsuario(int $idUsuario): int {
        $sql = "SELECT COUNT(*) FROM notificaciones WHERE id_usuario = ? AND leida = 0";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute([$idUsuario]);
        return (int) $stmt->fetchColumn();
    }
    
    // 2. Obtener notificaciones del usuario (ordenadas por fecha descendente)
    public function obtenerNotificacionesPorUsuario(int $idUsuario): array {
        $sql = "SELECT * FROM notificaciones WHERE id_usuario = ? ORDER BY fecha_creacion DESC";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute([$idUsuario]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // 3. Marcar todas como leídas
    public function marcarComoLeidas(int $idUsuario): bool {
        $sql = "UPDATE notificaciones SET leida = 1 WHERE id_usuario = ?";
        $stmt = $this->conexion->prepare($sql);
        return $stmt->execute([$idUsuario]);
    }

    // 4. Insertar una nueva notificación
    public function insertarNotificacion(int $idUsuario, int $idReserva, string $mensaje): bool {
        $sql = "INSERT INTO notificaciones (id_usuario, id_reserva, mensaje, leida, fecha)
                VALUES (?, ?, ?, 0, NOW())";
        $stmt = $this->conexion->prepare($sql);
        return $stmt->execute([$idUsuario, $idReserva, $mensaje]);
    }
}

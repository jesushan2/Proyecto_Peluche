<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../../app/controllers/RegistroController.php';
require_once __DIR__ . '/../../app/models/DAOregistro.php';

class RegistroControllerTest extends TestCase
{
    public function setUp(): void
    {
        $_POST = [];
        $_SESSION = [];
        $_SERVER['REQUEST_METHOD'] = 'POST';
    }

    public function testRegistroConCamposInvalidos()
    {
        $_POST = [
            'nombres' => '',  
            'apellidos' => '', 
            'telefono' => 'abc', 
            'correo' => 'correo-no-valido',
            'contraseña' => '12' 
        ];

        $mockDAO = $this->createMock(DAOregistro::class);
        $mockDAO->method('correoExiste')->willReturn(false);

        $controller = new RegistroController($mockDAO);
        $controller->activarModoTest();
        $controller->registrar();

        $this->assertArrayHasKey('registro_errores', $_SESSION);
        $this->assertGreaterThan(0, count($_SESSION['registro_errores']));
    }

    public function testRegistroConCorreoExistente()
    {
        $_POST = [
            'nombres' => 'Juan',
            'apellidos' => 'Pérez',
            'telefono' => '987654321',
            'correo' => 'ya@existe.com',
            'contraseña' => 'clave123'
        ];

        $mockDAO = $this->createMock(DAOregistro::class);
        $mockDAO->method('correoExiste')->willReturn(true);

        $controller = new RegistroController($mockDAO);
        $controller->activarModoTest();
        $controller->registrar();

        $this->assertArrayHasKey('registro_errores', $_SESSION);
        $this->assertContains('Este correo ya está en uso. Prueba otro.', $_SESSION['registro_errores']);
    }

    public function testRegistroExitoso()
    {
        $_POST = [
            'nombres' => 'Ana',
            'apellidos' => 'García',
            'telefono' => '987654321',
            'correo' => 'nuevo@correo.com',
            'contraseña' => 'clave123'
        ];

        $mockDAO = $this->createMock(DAOregistro::class);
        $mockDAO->method('correoExiste')->willReturn(false);
        $mockDAO->method('insertarUsuario')->willReturn(true);
        $mockDAO->method('obtenerUsuarioPorCorreo')->willReturn(['id_usuario' => 1]);

        $controller = new RegistroController($mockDAO);
        $controller->activarModoTest();
        $controller->registrar();

        $this->assertArrayHasKey('mensaje_exito', $_SESSION);
        $this->assertEquals('¡Cuenta registrada correctamente!', $_SESSION['mensaje_exito']);
    }

    public function testErrorAlInsertarUsuario()
    {
        $_POST = [
            'nombres' => 'Carlos',
            'apellidos' => 'Ramírez',
            'telefono' => '987654321',
            'correo' => 'error@insertar.com',
            'contraseña' => 'clave123'
        ];

        $mockDAO = $this->createMock(DAOregistro::class);
        $mockDAO->method('correoExiste')->willReturn(false);
        $mockDAO->method('insertarUsuario')->willReturn(false);

        $controller = new RegistroController($mockDAO);
        $controller->activarModoTest();
        $controller->registrar();

        $this->assertArrayHasKey('registro_errores', $_SESSION);
        $this->assertContains("❌ Error al registrar. Intenta más tarde.", $_SESSION['registro_errores']);
    }
}

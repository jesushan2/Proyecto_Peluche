<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../../app/controllers/ProductoController.php';

class ProductoControllerTest extends TestCase
{
    public function testCatalogoRetornaProductosEnModoTest()
    {
        $productosMock = [
            ['id_producto' => 1, 'nombre' => 'Peluchín', 'franquicia' => 'Marvel'],
            ['id_producto' => 2, 'nombre' => 'Osito', 'franquicia' => 'Disney']
        ];

        $daoMock = $this->createMock(DAOproducto::class);
        $daoMock->method('obtenerProductosConFranquicia')->willReturn($productosMock);

        $loggerMock = $this->createMock(LoggerWeb::class);
        $loggerMock->method('registrar')->willReturn(true);

        $_SESSION = ['usuario' => ['id_usuario' => 1]];

        $controller = new ProductoController($daoMock, $loggerMock);
        $controller->activarModoTest();
        $resultado = $controller->catalogo();

        $this->assertIsArray($resultado);
        $this->assertCount(2, $resultado);
        $this->assertEquals('Peluchín', $resultado[0]['nombre']);
        $this->assertEquals('Disney', $resultado[1]['franquicia']);
    }
}

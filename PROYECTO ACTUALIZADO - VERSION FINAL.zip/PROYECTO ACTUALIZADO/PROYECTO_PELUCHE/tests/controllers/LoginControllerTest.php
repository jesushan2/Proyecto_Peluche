<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../../app/controllers/LoginController.php';
require_once __DIR__ . '/../../app/models/DAOlogin.php';

class LoginControllerTest extends TestCase
{
    public function setUp(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $_SESSION = [];
        $_POST = [];
        $_SERVER['REQUEST_METHOD'] = 'POST';
    }

    public function testLoginConCorreoInvalido()
    {
        $_POST['correo'] = 'correo_invalido';
        $_POST['contraseña'] = '12345678';

        ob_start();
        $controller = new LoginController();
        $controller->activarModoTest();
        $controller->login();
        ob_end_clean();

        $this->assertArrayHasKey('error_login', $_SESSION);
        $this->assertEquals('Datos inválidos.', $_SESSION['error_login']);
    }

public function testLogoutEliminaSesion()
{
    $_SESSION = ['usuario' => ['id_usuario' => 1]];

    ob_start();
    $controller = new LoginController();
    $controller->activarModoTest();
    $controller->logout();
    ob_end_clean();

    $this->assertArrayNotHasKey('usuario', $_SESSION);
}

public function testLoginConContrasenaIncorrecta()
{
    $_SERVER['REQUEST_METHOD'] = 'POST';
    $_POST['correo'] = 'DivinidadV2@hotmail.com'; 
    $_POST['contraseña'] = 'contraseña_incorrecta'; 

    $_SESSION = [];

    ob_start();
    $controller = new LoginController();
    $controller->activarModoTest();
    $controller->login();
    ob_end_clean();


    $this->assertArrayHasKey('error_login', $_SESSION);
    $this->assertStringContainsString('incorrectos', $_SESSION['error_login']);
    
}

public function testBloqueoTrasTresIntentosFallidos()
{
    $_SERVER['REQUEST_METHOD'] = 'POST';
    $_POST['correo'] = 'DivinidadV2@hotmail.com';  
    $_POST['contraseña'] = 'contraseñamal';      


    $_SESSION = [
        'intentos_login' => 2,
        'bloqueado_hasta' => null
    ];

    ob_start();
    $controller = new LoginController();
    $controller->activarModoTest();
    $controller->login();
    ob_end_clean();

    $this->assertArrayHasKey('error_login', $_SESSION);
    $this->assertEquals(
        'Has superado los 3 intentos. Intenta nuevamente en 5 minutos.',
        $_SESSION['error_login']
    );

    $this->assertNotNull($_SESSION['bloqueado_hasta'], 'Se esperaba un valor para bloqueado_hasta');
    $this->assertGreaterThanOrEqual(time(), $_SESSION['bloqueado_hasta'], 'El tiempo de bloqueo debe ser en el futuro o ahora');
}


}


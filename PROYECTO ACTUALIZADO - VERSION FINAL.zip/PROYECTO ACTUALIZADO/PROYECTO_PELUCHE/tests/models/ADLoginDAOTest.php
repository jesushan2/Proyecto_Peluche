<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../../admin/models/ADLoginDAO.php';
require_once __DIR__ . '/../../config/database.php';

class ADLoginDAOTest extends TestCase {
    private ADLoginDAO $dao;

    protected function setUp(): void {
        $this->dao = new ADLoginDAO();
    }

    public function testObtenerUsuarioPorCorreoAdministradorExistente() {
           $correo = 'principal@example.com'; 
        $usuario = $this->dao->obtenerUsuarioPorCorreo($correo);

        if (!$usuario) {
            $this->markTestSkipped("No se encontró el administrador con el correo: $correo");
        }

        $this->assertIsArray($usuario);
        $this->assertEquals('admin', $usuario['rol']);
        $this->assertArrayHasKey('id', $usuario);
        $this->assertArrayHasKey('nombres', $usuario);
    }

    public function testObtenerUsuarioPorCorreoVendedorExistente() {
     $correo = 'Esperanza1@hotmail.com';
        $usuario = $this->dao->obtenerUsuarioPorCorreo($correo);

        if (!$usuario) {
            $this->markTestSkipped("No se encontró el vendedor con el correo: $correo");
        }

        $this->assertIsArray($usuario);
        $this->assertEquals('vendedor', $usuario['rol']);
        $this->assertArrayHasKey('clave', $usuario);
    }

    public function testObtenerUsuarioPorCorreoInexistente() {
        $correo = 'inexistente@correo.com';
        $usuario = $this->dao->obtenerUsuarioPorCorreo($correo);

        $this->assertNull($usuario);
    }
}

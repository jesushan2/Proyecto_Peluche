<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../../admin/models/ADUsuarioDAO.php';
require_once __DIR__ . '/../../config/database.php';

class ADUsuarioDAOTest extends TestCase {
    private ADUsuarioDAO $dao;

    protected function setUp(): void {
        $this->dao = new ADUsuarioDAO();
    }

    public function testCorreoExiste() {
        $correoExistente = 'CorazonesV2@hotmail.com'; 
        $this->assertTrue($this->dao->correoExiste($correoExistente));
    }

    public function testCorreoNoExiste() {
        $correoFalso = 'no_existe_' . uniqid() . '@test.com';
        $this->assertFalse($this->dao->correoExiste($correoFalso));
    }

    public function testRegistrarAdministrador() {
        $datos = [
            'nombres' => 'Test',
            'apellidos' => 'Admin',
            'telefono' => '987654321',
            'correo' => 'test_admin_' . uniqid() . '@mail.com',
            'clave' => '123456'
        ];

        $resultado = $this->dao->registrarAdministrador($datos);
        $this->assertTrue($resultado);


        $this->assertTrue($this->dao->correoExiste($datos['correo']));
    }

 
    public function testObtenerAdministradoresActivos() {
        $admins = $this->dao->obtenerAdministradoresActivos();
        $this->assertIsArray($admins);
    }


    public function testActualizarAdministrador() {
    
        $datos = [
            'nombres' => 'Editar',
            'apellidos' => 'Prueba',
            'telefono' => '123456789',
            'correo' => 'actualizar_' . uniqid() . '@mail.com',
            'clave' => 'clave'
        ];
        $this->dao->registrarAdministrador($datos);

        $admins = $this->dao->obtenerAdministradoresActivos();
        $nuevoAdmin = end($admins); 
        $id = $nuevoAdmin['id_admin'];

        $actualizado = $this->dao->actualizarAdministrador($id, [
            'nombres' => 'Editado',
            'apellidos' => 'Modificado',
            'telefono' => '000111222',
            'correo' => 'editado_' . uniqid() . '@mail.com'
        ]);

        $this->assertTrue($actualizado);
    }

    public function testDesactivarAdministrador() {
        $datos = [
            'nombres' => 'Eliminar',
            'apellidos' => 'Admin',
            'telefono' => '123123123',
            'correo' => 'desactivar_' . uniqid() . '@mail.com',
            'clave' => 'clave'
        ];
        $this->dao->registrarAdministrador($datos);

        $admins = $this->dao->obtenerAdministradoresActivos();
        $nuevo = end($admins);
        $id = $nuevo['id_admin'];

        $desactivado = $this->dao->desactivarAdministrador($id);
        $this->assertTrue($desactivado);
    }
}

<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../../app/models/DAOproducto.php';
require_once __DIR__ . '/../../config/database.php';

class DAOproductoTest extends TestCase
{
    private $dao;

    protected function setUp(): void
    {
 
        $conexion = Database::connect();
        
        $this->dao = new DAOproducto($conexion);
    }

    public function testObtenerProductosConFranquiciaDevuelveArray()
    {
        $productos = $this->dao->obtenerProductosConFranquicia();
    
        $this->assertIsArray($productos, "El resultado debe ser un array.");
    
        foreach ($productos as $producto) {
            $this->assertIsArray($producto);
            $this->assertArrayHasKey('id_producto', $producto);
            $this->assertArrayHasKey('nombre_prod', $producto, 'Falta el campo nombre_prod');
            $this->assertArrayHasKey('franquicia', $producto, 'Falta el campo franquicia');
        }
    }
    
}

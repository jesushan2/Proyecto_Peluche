<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../../admin/models/ADFranquiciaDAO.php';
require_once __DIR__ . '/../../config/database.php';

class ADFranquiciaDAOTest extends TestCase {
    private ADFranquiciaDAO $dao;

    protected function setUp(): void {
        $this->dao = new ADFranquiciaDAO();
    }

    public function testRegistrarFranquicia() {
        $nombre = 'Franquicia de prueba ' . uniqid();
        $resultado = $this->dao->registrarFranquicia($nombre);
        $this->assertTrue($resultado, "No se pudo registrar la franquicia.");
    }

    public function testObtenerTodas() {
        $franquicias = $this->dao->obtenerTodas();
        $this->assertIsArray($franquicias);
        if (!empty($franquicias)) {
            $this->assertArrayHasKey('id_franquicia', $franquicias[0]);
            $this->assertArrayHasKey('nombre_fran', $franquicias[0]);
        }
    }

    public function testActualizarYObtenerPorId() {
       
        $nombre = 'Actualizar prueba ' . uniqid();
        $this->dao->registrarFranquicia($nombre);
        $todas = $this->dao->obtenerTodas();
        $ultima = end($todas);
        $id = $ultima['id_franquicia'];

        $nuevoNombre = 'Nombre actualizado ' . uniqid();
        $estadoNuevo = 1;
        $actualizado = $this->dao->actualizarFranquicia($id, $nuevoNombre, $estadoNuevo);
        $this->assertTrue($actualizado);

        $franquicia = $this->dao->obtenerPorId($id);
        $this->assertNotNull($franquicia);
        $this->assertEquals($nuevoNombre, $franquicia['nombre_fran']);
    }

    public function testEliminarFranquicia() {
       
        $nombre = 'Franquicia a eliminar ' . uniqid();
        $this->dao->registrarFranquicia($nombre);
        $todas = $this->dao->obtenerTodas();
        $ultima = end($todas);
        $id = $ultima['id_franquicia'];

        $eliminado = $this->dao->eliminarFranquicia($id);
        $this->assertTrue($eliminado);

    
        $franquicias = $this->dao->obtenerTodas();
        $ids = array_column($franquicias, 'id_franquicia');
        $this->assertNotContains($id, $ids);
    }
}

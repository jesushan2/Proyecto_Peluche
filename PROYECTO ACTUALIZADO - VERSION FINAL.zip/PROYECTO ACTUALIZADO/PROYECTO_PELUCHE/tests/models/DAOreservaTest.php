<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../../app/models/DAOreserva.php';
require_once __DIR__ . '/../../config/database.php';

class DAOreservaTest extends TestCase
{
    private DAOreserva $dao;

    protected function setUp(): void
    {
        $this->dao = new DAOreserva();
        if (session_status() === PHP_SESSION_NONE) session_start();
        $_SESSION['usuario']['id_usuario'] = 999;
    }

    public function testInsertarReservaDevuelveIdValido()
    {
        $idReserva = $this->dao->insertarReserva(1, 1, 100.0); 

        $this->assertIsInt($idReserva);
        $this->assertGreaterThan(0, $idReserva, "El ID de la reserva debe ser mayor que 0.");
    }

    public function testInsertarDetalleReservaNoLanzaExcepcion()
    {
        $idReserva = $this->dao->insertarReserva(1, 1, 200.0);
        $excepcion = null;

        try {
            $this->dao->insertarDetalleReserva($idReserva, 1, 2, 25.0); 
        } catch (Exception $e) {
            $excepcion = $e;
        }

        $this->assertNull($excepcion, "insertarDetalleReserva lanzó una excepción inesperada.");
    }

    public function testActualizarStockProductoDisminuyeStock()
    {
        $stockInicial = $this->dao->obtenerStockProducto(1); 
        $this->dao->actualizarStockProducto(1, 1);
        $stockFinal = $this->dao->obtenerStockProducto(1);

        $this->assertEquals($stockInicial - 1, $stockFinal, "El stock no fue reducido correctamente.");
    }

    public function testObtenerStockProductoRetornaEntero()
    {
        $stock = $this->dao->obtenerStockProducto(1); 

        $this->assertIsInt($stock, "El stock debe ser un entero.");
        $this->assertGreaterThanOrEqual(0, $stock, "El stock no puede ser negativo.");
    }
}

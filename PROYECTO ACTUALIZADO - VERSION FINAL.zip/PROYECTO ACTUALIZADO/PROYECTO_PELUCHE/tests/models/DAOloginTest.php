<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../../app/models/DAOlogin.php';
require_once __DIR__ . '/../../config/database.php';

class DAOloginTest extends TestCase
{
    private $conexion;

    protected function setUp(): void
    {
        $this->conexion = Database::connect();
    }

    public function testObtenerPorCorreoExistente()
    {
        $correo = 'PrincesaV2@hotmail.com';
        $usuario = DAOlogin::ObtenerPorCorreo($this->conexion, $correo);

        $this->assertIsArray($usuario);
        $this->assertEquals($correo, $usuario['correo']);
    }

    public function testObtenerPorCorreoInexistente()
    {
        $correo = 'correo_que_no_existe@prueba.com';
        $usuario = DAOlogin::ObtenerPorCorreo($this->conexion, $correo);

        $this->assertNull($usuario);
    }
}

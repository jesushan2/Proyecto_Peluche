<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../../admin/models/ADReservaDAO.php';
require_once __DIR__ . '/../../config/database.php';

class ADReservaDAOTest extends TestCase {
    private ADReservaDAO $dao;

    protected function setUp(): void {
        $this->dao = new ADReservaDAO();
    }

    public function testObtenerTodasReservas() {
        $reservas = $this->dao->obtenerTodasReservas();
        $this->assertIsArray($reservas);
    }

    public function testObtenerEstados() {
        $estados = $this->dao->obtenerEstados();
        $this->assertIsArray($estados);
        if (!empty($estados)) {
            $this->assertArrayHasKey('id_estado', $estados[0]);
            $this->assertArrayHasKey('nombre_est', $estados[0]);
        }
    }

    public function testObtenerVendedores() {
        $vendedores = $this->dao->obtenerVendedores();
        $this->assertIsArray($vendedores);
        if (!empty($vendedores)) {
            $this->assertArrayHasKey('id_vendedor', $vendedores[0]);
        }
    }

    public function testObtenerNombreEstadoPorId() {
        $estados = $this->dao->obtenerEstados();
        if (!empty($estados)) {
            $nombre = $this->dao->obtenerNombreEstadoPorId($estados[0]['id_estado']);
            $this->assertIsString($nombre);
            $this->assertEquals($estados[0]['nombre_est'], $nombre);
        } else {
            $this->markTestSkipped('No hay estados en la tabla estados_reserva.');
        }
    }

  
    public function testObtenerHistorialPorReserva() {
        $reservas = $this->dao->obtenerTodasReservas();
        if (empty($reservas)) {
            $this->markTestSkipped('No hay reservas para probar historial.');
        }

        $reserva = $reservas[0];
        $historial = $this->dao->obtenerHistorialPorReserva($reserva['id_reserva']);
        $this->assertIsArray($historial);
    }
}

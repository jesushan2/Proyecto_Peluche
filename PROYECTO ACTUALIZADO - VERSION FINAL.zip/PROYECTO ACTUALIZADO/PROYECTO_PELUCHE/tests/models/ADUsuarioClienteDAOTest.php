<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../../admin/models/ADUsuarioClienteDAO.php';
require_once __DIR__ . '/../../config/database.php';

class ADUsuarioClienteDAOTest extends TestCase {
    private ADUsuarioClienteDAO $dao;

    protected function setUp(): void {
        $this->dao = new ADUsuarioClienteDAO();
    }

    public function testObtenerTodosUsuariosActivos() {
        $usuarios = $this->dao->obtenerTodos();
        $this->assertIsArray($usuarios);
        if (!empty($usuarios)) {
            $this->assertArrayHasKey('id_usuario', $usuarios[0]);
            $this->assertEquals(1, $usuarios[0]['estado_activo']);
        }
    }

   
   
}

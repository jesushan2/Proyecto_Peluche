<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../../admin/models/ADProductoDAO.php';
require_once __DIR__ . '/../../config/database.php';

class ADProductoDAOTest extends TestCase {
    private ADProductoDAO $dao;
    private PDO $conexion;

    protected function setUp(): void {
        $this->dao = new ADProductoDAO();
        $this->conexion = Database::connect();
    }

    public function testObtenerFranquicias() {
        $franquicias = $this->dao->obtenerFranquicias();
        $this->assertIsArray($franquicias);
    }

   

    public function testObtenerTodosProductos() {
        $productos = $this->dao->obtenerTodosProductos();
        $this->assertIsArray($productos);
        if (!empty($productos)) {
            $this->assertArrayHasKey('id_producto', $productos[0]);
            $this->assertArrayHasKey('nombre_prod', $productos[0]);
        }
    }
}

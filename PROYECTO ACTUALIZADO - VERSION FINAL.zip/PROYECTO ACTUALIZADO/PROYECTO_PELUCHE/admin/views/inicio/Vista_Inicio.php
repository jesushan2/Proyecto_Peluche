<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['usuario_nombre']) || !isset($_SESSION['usuario_rol'])) {
    header("Location: /PROYECTO_PELUCHE/admin/login/index");
    exit();
}


$rol = $_SESSION['usuario_rol'];
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Panel de <?= ucfirst($rol) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <link rel="stylesheet" href="/PROYECTO_PELUCHE/STYLE/INICIO.css">
</head>

<body>

    <div class="dashboard-container">

        <div class="sidebar">
            <div class="profile">
                <img src="/PROYECTO_PELUCHE/image/Goffy.png" alt="Perfil">
                <h3><?= htmlspecialchars($_SESSION['usuario_nombre']) ?></h3>
                <p><?= htmlspecialchars($rol) ?></p>
            </div>
            <ul>
                <?php if ($rol === 'admin'): ?>
                    <li id="reservas-link" class="submenu">
                        <a href="#"><i class="fas fa-calendar-plus"></i> <span style="flex-grow: 1;">Reservas</span> <i
                                class="fas fa-caret-down"></i></a>
                        <ul id="submenu-reservas" class="submenu-items" style="display: none;">
                            <li>
                                <a onclick="document.getElementById('iframe-contenido').src='/PROYECTO_PELUCHE/admin/reserva/mostrarListadoReservas'; return false;"
                                    href="#">Ver reservas</a>
                            </li>
                        </ul>
                    </li>
                    <li class="submenu">
                        <a href="#" id="productos-link">
                            <i class="fas fa-box"></i>
                            <span style="flex-grow: 1;">Productos</span>
                            <i class="fas fa-caret-down" style="margin-left: auto;"></i>
                        </a>
                        <ul id="submenu-productos" class="submenu-items" style="display: none;">
                            <li><a href="/PROYECTO_PELUCHE/admin/producto/mostrarFormularioProducto"
                                    target="iframe-contenido">Registrar Nuevos Productos</a></li>
                            <li><a href="/PROYECTO_PELUCHE/admin/producto/mostrarListadoProductos"
                                    target="iframe-contenido">Editar Productos Registrados</a></li>
                        </ul>
                    </li>
                    <li class="submenu">
                        <a href="#" id="franquicias-link">
                            <i class="fas fa-store"></i>
                            <span style="flex-grow: 1;">Franquicias</span>
                            <i class="fas fa-caret-down" style="margin-left: auto;"></i>
                        </a>
                        <ul id="submenu-franquicias" class="submenu-items" style="display: none;">
                            <li><a href="/PROYECTO_PELUCHE/admin/franquicia/mostrarFormularioFranquicia"
                                    target="iframe-contenido">Registrar Nuevas Franquicias</a></li>
                            <li><a href="/PROYECTO_PELUCHE/admin/franquicia/listarFranquicias"
                                    target="iframe-contenido">Editar Franquicias Nuevas</a></li>
                        </ul>
                    </li>
                    <li class="submenu">
                        <a href="#" id="usuarios-link">
                            <i class="fas fa-users"></i>
                            <span style="flex-grow: 1;">Usuarios</span>
                            <i class="fas fa-caret-down" style="margin-left: auto;"></i>
                        </a>
                        <ul id="submenu-usuarios" class="submenu-items" style="display: none;">
                            <li><a href="/PROYECTO_PELUCHE/admin/usuario/mostrarFormularioVendedor"
                                    target="iframe-contenido">Registrar Nuevos Vendedores</a></li>
                            <li><a href="/PROYECTO_PELUCHE/admin/usuario/mostrarFormularioAdministrador"
                                    target="iframe-contenido">Registrar Nuevos Administradores</a></li>
                            <li><a href="/PROYECTO_PELUCHE/admin/usuarioCliente/listarClientes"
                                    target="iframe-contenido">Gestionar Clientes</a></li>
                            <li><a href="/PROYECTO_PELUCHE/admin/usuario/listarAdministradores"
                                    target="iframe-contenido">Gestionar Administradores</a></li>
                            <li><a href="/PROYECTO_PELUCHE/admin/usuario/listarVendedores"
                                    target="iframe-contenido">Gestionar Vendedores</a></li>
                        </ul>
                    </li>
                    <li class="submenu">
                        <a href="#" id="historial-link">
                            <i class="fas fa-history"></i>
                            <span style="flex-grow: 1;">Historial de Reservas</span>
                            <i class="fas fa-caret-down" style="margin-left: auto;"></i>
                        </a>
                        <ul id="submenu-historial" class="submenu-items" style="display: none;">
                            <li><a href="/PROYECTO_PELUCHE/admin/reserva/mostrarSoloHistorialReservas"
                                    target="iframe-contenido">Ver Historial de la Reserva</a></li>
                        </ul>
                    </li>
                    <li class="submenu">
                        <a href="#" id="vistas-link">
                            <i class="fas fa-eye"></i>
                            <span style="flex-grow: 1;">Vistas</span>
                            <i class="fas fa-caret-down" style="margin-left: auto;"></i>
                        </a>
                        <ul id="submenu-vistas" class="submenu-items" style="display: none;">
                            <li><a href="/PROYECTO_PELUCHE/admin/reserva/verVistaReservas" target="iframe-contenido">Ver
                                    Todas las Reservas</a>
                            </li>
                            <li><a href="/PROYECTO_PELUCHE/admin/producto/verVistaProductos" target="iframe-contenido">Vista
                                    de Productos</a>
                            </li>
                        </ul>
                    </li>
                    <li class="submenu">
                        <a href="#" id="logs-link">
                            <i class="fas fa-file-alt"></i>
                            <span style="flex-grow: 1;">Logs</span>
                            <i class="fas fa-caret-down" style="margin-left: auto;"></i>
                        </a>
                        <ul id="submenu-logs" class="submenu-items" style="display: none;">
                            <li><a href="/PROYECTO_PELUCHE/admin/log/index" target="iframe-contenido">Ver actividad</a></li>
                        </ul>
                    </li>

                <?php elseif ($rol === 'vendedor'): ?>
                    <li class="submenu">
                        <a href="#" id="productos-link">
                            <i class="fas fa-box"></i>
                            <span style="flex-grow: 1;">Productos</span>
                            <i class="fas fa-caret-down" style="margin-left: auto;"></i>
                        </a>
                        <ul id="submenu-productos" class="submenu-items" style="display: none;">
                            <li><a href="/PROYECTO_PELUCHE/admin/producto/mostrarFormularioProducto"
                                    target="iframe-contenido">Registrar Nuevos Productos</a></li>
                        </ul>
                    </li>
                    <li class="submenu">
                        <a href="#" id="franquicias-link">
                            <i class="fas fa-store"></i>
                            <span style="flex-grow: 1;">Franquicias</span>
                            <i class="fas fa-caret-down" style="margin-left: auto;"></i>
                        </a>
                        <ul id="submenu-franquicias" class="submenu-items" style="display: none;">
                            <li><a href="/PROYECTO_PELUCHE/admin/franquicia/mostrarFormularioFranquicia"
                                    target="iframe-contenido">Registrar Nuevas Franquicias</a></li>
                        </ul>
                    </li>

                    <li id="reservero-link" class="submenu">
                        <a href="#">
                            <i class="fas fa-calendar-plus"></i>
                            <span style="flex-grow: 1;">Reservas</span>
                            <i class="fas fa-caret-down"></i>
                        </a>
                        <ul id="submenu-reservero" class="submenu-items" style="display: none;">
                            <li>
                            <a href="/PROYECTO_PELUCHE/admin/reserva/mostrarReservasVendedor"
                            target="iframe-contenido">Mis Reservas Asignadas</a></li>
                        
                           </li>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
        </div>

        <div class="content-area">
            <div class="topbar">
                <div class="title">Panel de Control - <?= ucfirst($rol) ?></div>
                <div class="profile-dropdown" onclick="toggleDropdown()">
                    <img src="/PROYECTO_PELUCHE/image/Goffy.png" alt="Perfil" class="profile-img">
                    <span class="username"><?= htmlspecialchars($_SESSION['usuario_nombre']) ?></span>
                    <i class="fas fa-chevron-down"></i>
                    <div id="dropdown-menu" class="dropdown-menu">
                        <a href="/PROYECTO_PELUCHE/admin/views/perfil/PerfilUsuario.php" target="iframe-contenido">
                            <i class="fas fa-user"></i> Mi Perfil
                        </a>
                        <a href="/PROYECTO_PELUCHE/admin/login/cerrarSesion"><i class="fas fa-sign-out-alt"></i> Cerrar
                            Sesión</a>
                    </div>
                </div>
            </div>
            <div class="main-content">
                <iframe id="iframe-contenido" name="iframe-contenido"
                    src="/PROYECTO_PELUCHE/admin/views/estadisticas/estadisticasDashboard.php" frameborder="0"
                    style="width: 100%;border: none;"></iframe>
            </div>
            <footer class="footer">
                <p>&copy; <?= date('Y') ?> TODO BARRANCA - Todos los derechos reservados</p>
            </footer>
        </div>
    </div>
    <script src="/PROYECTO_PELUCHE/JS/JS_DE_PANEL_ADMINISTRATIVO.js" defer></script>

    <script>

    </script>
</body>

</html>
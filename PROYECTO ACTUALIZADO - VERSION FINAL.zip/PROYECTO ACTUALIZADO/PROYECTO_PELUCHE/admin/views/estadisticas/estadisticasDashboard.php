<?php
if (session_status() === PHP_SESSION_NONE) session_start();

require_once __DIR__ . '/../../models/ADEstadisticasDAO.php';
$estadisticasDAO = new ADEstadisticasDAO();

$hoy = $estadisticasDAO->contarReservasHoy();
$semana = $estadisticasDAO->contarReservasSemana();
$mes = $estadisticasDAO->contarReservasMes();

$estados = $estadisticasDAO->obtenerReservasPorEstado();
$labels = array_column($estados, 'nombre_est');
$datos = array_column($estados, 'total');

$topProductos = $estadisticasDAO->obtenerTopProductos();
$totalUsuarios = $estadisticasDAO->contarUsuariosActivos();
$totalVendedores = $estadisticasDAO->contarVendedoresActivos();
$logs = $estadisticasDAO->obtenerUltimosLogs();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Estadístico</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<div class="container mt-4">
    <h2 class="mb-4">Resumen General</h2>

    <!-- Secciones: Totales -->
    <div class="row text-center mb-4">
        <div class="col-md-4">
            <div class="card shadow">
                <div class="card-body">
                    <h5 class="card-title">Reservas Hoy</h5>
                    <p class="card-text fs-3 text-primary"><?= $hoy ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow">
                <div class="card-body">
                    <h5 class="card-title">Reservas Semana</h5>
                    <p class="card-text fs-3 text-success"><?= $semana ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow">
                <div class="card-body">
                    <h5 class="card-title">Reservas Mes</h5>
                    <p class="card-text fs-3 text-warning"><?= $mes ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Gráfico y Top 5 -->
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-body">
                    <h5 class="card-title text-center">Reservas por Estado</h5>
                    <canvas id="graficoEstados"></canvas>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-body">
                    <h5 class="card-title text-center">Top 5 Productos Más Reservados</h5>
                    <table class="table table-bordered table-sm">
                        <thead>
                            <tr><th>Producto</th><th>Cantidad</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($topProductos as $p): ?>
                                <tr>
                                    <td><?= htmlspecialchars($p['nombre_prod']) ?></td>
                                    <td><?= $p['total_reservado'] ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Usuarios, Vendedores y Logs -->
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card shadow text-center">
                <div class="card-body">
                    <h5 class="card-title">Usuarios Activos</h5>
                    <p class="fs-3 text-info"><?= $totalUsuarios ?></p>
                </div>
            </div>
            <div class="card shadow text-center mt-3">
                <div class="card-body">
                    <h5 class="card-title">Vendedores Activos</h5>
                    <p class="fs-3 text-info"><?= $totalVendedores ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card shadow">
                <div class="card-body">
                    <h5 class="card-title text-center">Últimos Logs del Sistema</h5>
                    <table class="table table-sm table-striped">
                        <thead>
                            <tr><th>Usuario</th><th>Acción</th><th>IP</th><th>Fecha</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($logs as $log): ?>
                                <tr>
                                    <td><?= htmlspecialchars($log['nombres'] . ' ' . $log['apellidos']) ?></td>
                                    <td><?= htmlspecialchars($log['accion']) ?></td>
                                    <td><?= $log['ip_usuario'] ?></td>
                                    <td><?= $log['fecha'] ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
const ctx = document.getElementById('graficoEstados').getContext('2d');
new Chart(ctx, {
    type: 'pie',
    data: {
        labels: <?= json_encode($labels) ?>,
        datasets: [{
            data: <?= json_encode($datos) ?>,
            backgroundColor: ['#4e73df', '#1cc88a', '#f6c23e', '#e74a3b', '#36b9cc']
        }]
    }
});
</script>
</body>
</html>

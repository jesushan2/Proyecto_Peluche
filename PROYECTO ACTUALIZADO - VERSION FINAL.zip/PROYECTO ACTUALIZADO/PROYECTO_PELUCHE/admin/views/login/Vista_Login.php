<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login - Panel Administrativo</title>
    <link rel="stylesheet" href="/PROYECTO_PELUCHE/style3/Estilo_de_login.css" />
    <script src="/PROYECTO_PELUCHE/JS/"></script>
</head>
<body>
    <h2>Iniciar Sesión</h2>

    <?php if (!empty($_SESSION['error'])): ?>
        <p style="color:red;"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></p>
    <?php endif; ?>

    <form method="POST" action="/PROYECTO_PELUCHE/admin/login/autenticar">
        <label>Correo:</label><br>
        <input type="email" name="correo" required><br><br>

        <label>Contraseña:</label><br>
        <input type="password" name="clave" required><br><br>

        <button type="submit">Ingresar</button>
    </form>
</body>
</html>

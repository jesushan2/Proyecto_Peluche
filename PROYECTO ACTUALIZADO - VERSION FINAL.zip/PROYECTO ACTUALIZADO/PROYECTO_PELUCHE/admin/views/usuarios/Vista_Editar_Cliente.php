<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<div class="form-container">
    <h2>Editar Cliente</h2>

    <form method="POST" action="/PROYECTO_PELUCHE/admin/usuarioCliente/procesarEdicion">
        <input type="hidden" name="id_usuario" value="<?= $usuario['id_usuario'] ?>">

        <label>Nombres:</label>
        <input type="text" name="nombres" value="<?= htmlspecialchars($usuario['nombres']) ?>" required>

        <label>Apellidos:</label>
        <input type="text" name="apellidos" value="<?= htmlspecialchars($usuario['apellidos']) ?>" required>

        <label>Teléfono:</label>
        <input type="text" name="telefono" value="<?= htmlspecialchars($usuario['telefono']) ?>" required>

        <label>Correo:</label>
        <input type="email" name="correo" value="<?= htmlspecialchars($usuario['correo']) ?>" required>

        <button type="submit">Actualizar</button>
    </form>
</div>
<link rel="stylesheet" href="/PROYECTO_PELUCHE/STYLE/GENERAL_REGISTRO.css">
<script src="/PROYECTO_PELUCHE/JS/JS_DE_ADMINISTRADOR.js" defer></script>

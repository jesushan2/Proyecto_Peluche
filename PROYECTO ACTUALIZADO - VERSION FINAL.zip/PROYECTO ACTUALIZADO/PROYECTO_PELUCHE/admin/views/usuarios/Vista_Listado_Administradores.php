<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<div class="form-container">
    <h2>Listado de Administradores</h2>

    <?php if (!empty($_SESSION['mensaje'])): ?>
        <div class="mensaje"><?= htmlspecialchars($_SESSION['mensaje']); unset($_SESSION['mensaje']); ?></div>
    <?php elseif (!empty($_SESSION['error'])): ?>
        <div class="error"><?= htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <table style="width:100%; border-collapse: collapse; margin-top: 20px;">
        <thead>
            <tr style="background-color: #f5f5f5;">
                <th>ID</th>
                <th>Nombres</th>
                <th>Apellidos</th>
                <th>Teléfono</th>
                <th>Correo</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($admins as $admin): ?>
                <tr style="text-align: center; border-bottom: 1px solid #ccc;">
                    <td><?= $admin['id_admin'] ?></td>
                    <td><?= htmlspecialchars($admin['nombres']) ?></td>
                    <td><?= htmlspecialchars($admin['apellidos']) ?></td>
                    <td><?= $admin['telefono'] ?></td>
                    <td><?= $admin['correo'] ?></td>
                    <td>
                        <a href="/PROYECTO_PELUCHE/admin/usuario/editarAdministrador?id=<?= $admin['id_admin'] ?>"
                           target="iframe-contenido" style="color: #007bff;">Editar</a>
                        |
                        <a href="/PROYECTO_PELUCHE/admin/usuario/eliminarAdministrador?id=<?= $admin['id_admin'] ?>"
                           onclick="return confirm('¿Seguro de desactivar este administrador?')"
                           style="color: red;">Eliminar</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<link rel="stylesheet" href="/PROYECTO_PELUCHE/STYLE/GENERAL_LISTA.css">

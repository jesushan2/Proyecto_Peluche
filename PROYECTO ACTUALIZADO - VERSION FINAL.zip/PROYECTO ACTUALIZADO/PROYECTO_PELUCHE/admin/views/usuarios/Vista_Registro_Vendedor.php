<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$mensaje = $_SESSION['mensaje'] ?? null;
$error = $_SESSION['error'] ?? null;
unset($_SESSION['mensaje'], $_SESSION['error']);
?>


<div class="form-container">
    <h2>Registrar Vendedor</h2>

    <?php if ($mensaje): ?>
        <p class="mensaje" style="color: green;"><?= htmlspecialchars($mensaje) ?></p>
    <?php endif; ?>

    <?php if ($error): ?>
        <p class="error" style="color: red;"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <form method="post" action="/PROYECTO_PELUCHE/admin/usuario/procesarRegistroVendedor" id="formRegistroVendedor">
        <input type="text" name="nombres" placeholder="Nombres" required>
        <input type="text" name="apellidos" placeholder="Apellidos" required>
        <input type="text" name="telefono" placeholder="Teléfono (9 dígitos)" maxlength="9" required>
        <input type="email" name="correo" placeholder="Correo electrónico" required>
        <input type="password" name="clave" placeholder="Contraseña" required>
        <button type="submit">Registrar</button>
    </form>
</div>
<script src="/PROYECTO_PELUCHE/JS/JS_DE_VENDEDOR.js" defer></script>
<link rel="stylesheet" href="/PROYECTO_PELUCHE/STYLE/GENERAL_REGISTRO.css">

<?php
if (session_status() === PHP_SESSION_NONE) session_start();
?>

<div class="form-container">
    <h2>Registrar Administrador</h2>

    <?php if (!empty($_SESSION['mensaje'])): ?>
        <p class="mensaje"><?= htmlspecialchars($_SESSION['mensaje']) ?></p>
        <?php unset($_SESSION['mensaje']); ?>
    <?php endif; ?>

    <?php if (!empty($_SESSION['error'])): ?>
        <p class="error"><?= htmlspecialchars($_SESSION['error']) ?></p>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <form method="POST" action="/PROYECTO_PELUCHE/admin/usuario/procesarRegistroAdministrador" onsubmit="return validarFormularioAdmin();">
        <input type="text" name="nombres" placeholder="Nombres" required>
        <input type="text" name="apellidos" placeholder="Apellidos" required>
        <input type="text" name="telefono" placeholder="Teléfono (9 dígitos)" pattern="\d{9}" required>
        <input type="email" name="correo" placeholder="Correo electrónico" required>
        <input type="password" name="clave" placeholder="Contraseña" minlength="6" required>
        <button type="submit">Registrar</button>
    </form>
</div>
<script src="/PROYECTO_PELUCHE/JS/JS_DE_ADMINISTRADOR.js" defer></script>
<link rel="stylesheet" href="/PROYECTO_PELUCHE/STYLE/GENERAL_REGISTRO.css">






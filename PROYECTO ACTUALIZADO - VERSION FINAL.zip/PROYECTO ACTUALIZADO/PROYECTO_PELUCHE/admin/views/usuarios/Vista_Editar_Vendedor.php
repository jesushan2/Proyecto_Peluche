<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<div class="form-container">
    <h2>Editar Vendedor</h2>

    <form action="/PROYECTO_PELUCHE/admin/usuario/procesarEditarVendedor" method="post">
        <input type="hidden" name="id_vendedor" value="<?= $vendedor['id_vendedor'] ?>">

        <label>Nombres:</label>
        <input type="text" name="nombres" value="<?= htmlspecialchars($vendedor['nombres']) ?>" required>

        <label>Apellidos:</label>
        <input type="text" name="apellidos" value="<?= htmlspecialchars($vendedor['apellidos']) ?>" required>

        <label>Teléfono:</label>
        <input type="text" name="telefono" value="<?= htmlspecialchars($vendedor['telefono']) ?>" required>

        <label>Correo:</label>
        <input type="email" name="correo" value="<?= htmlspecialchars($vendedor['correo']) ?>" required>

        <button type="submit">Guardar Cambios</button>
    </form>
</div>
<link rel="stylesheet" href="/PROYECTO_PELUCHE/STYLE/GENERAL_REGISTRO.css">
<script src="/PROYECTO_PELUCHE/JS/JS_DE_ADMINISTRADOR.js" defer></script>

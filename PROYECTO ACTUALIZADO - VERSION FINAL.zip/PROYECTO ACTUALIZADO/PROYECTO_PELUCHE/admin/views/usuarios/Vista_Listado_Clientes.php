<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<div class="form-container">
    <h2>Lista de Clientes Registrados</h2>

    <?php if (!empty($_SESSION['mensaje'])): ?>
        <div class="mensaje"><?= htmlspecialchars($_SESSION['mensaje']); unset($_SESSION['mensaje']); ?></div>
    <?php elseif (!empty($_SESSION['error'])): ?>
        <div class="error"><?= htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <table style="width:100%; border-collapse: collapse; margin-top: 20px;">
        <thead>
            <tr style="background-color: #f5f5f5;">
                <th>ID</th>
                <th>Nombre</th>
                <th>Apellidos</th>
                <th>Teléfono</th>
                <th>Correo</th>
                <th>Fecha</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($usuarios as $u): ?>
            <tr style="text-align: center; border-bottom: 1px solid #ccc;">
                <td><?= $u['id_usuario'] ?></td>
                <td><?= htmlspecialchars($u['nombres']) ?></td>
                <td><?= htmlspecialchars($u['apellidos']) ?></td>
                <td><?= htmlspecialchars($u['telefono']) ?></td>
                <td><?= htmlspecialchars($u['correo']) ?></td>
                <td><?= $u['fecha_registro'] ?></td>
                <td>
     

                    <a href="/PROYECTO_PELUCHE/admin/usuarioCliente/editarUsuario?id=<?= $u['id_usuario'] ?>" 
                       target="iframe-contenido" style="color: #007bff; margin-right: 10px;">Editar</a>
                    <a href="/PROYECTO_PELUCHE/admin/usuarioCliente/eliminarUsuario?id=<?= $u['id_usuario'] ?>" 
                       onclick="return confirm('¿Deseas desactivar este cliente?')" 
                       style="color: red;">Eliminar</a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<link rel="stylesheet" href="/PROYECTO_PELUCHE/STYLE/GENERAL_LISTA.css">

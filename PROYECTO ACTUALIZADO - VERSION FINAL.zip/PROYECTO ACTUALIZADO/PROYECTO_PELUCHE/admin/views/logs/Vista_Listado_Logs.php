<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<div class="form-container">
    <h2>Registro de Actividades</h2>

    <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <thead class="table-primary">
                <tr>
                    <th>ID</th>
                    <th>Usuario</th>
                    <th>Acción</th>
                    <th>Descripción</th>
                    <th>IP</th>
                    <th>User Agent</th>
                    <th>Fecha</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($logs as $log): ?>
                    <tr>
                        <td><?= htmlspecialchars($log['id_log']) ?></td>
                        <td><?= htmlspecialchars($log['id_usuario']) ?></td>
                        <td><?= htmlspecialchars($log['accion']) ?></td>
                        <td><?= htmlspecialchars($log['descripcion']) ?></td>
                        <td><?= htmlspecialchars($log['ip_usuario']) ?></td>
                        <td><?= htmlspecialchars($log['user_agent']) ?></td>
                        <td><?= htmlspecialchars($log['fecha']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<link rel="stylesheet" href="/PROYECTO_PELUCHE/STYLE/GENERAL_LISTA.css">

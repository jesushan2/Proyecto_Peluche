<?php
if (session_status() === PHP_SESSION_NONE) session_start();

require_once __DIR__ . '/../../../config/database.php';

if (!isset($_SESSION['usuario_id']) || !isset($_SESSION['usuario_rol'])) {
    die("No hay sesión activa");
}

$conn = Database::connect();
$id = $_SESSION['usuario_id'];
$rol = $_SESSION['usuario_rol'];

$sql = $rol === 'admin'
    ? "SELECT nombres, apellidos, correo, telefono, rol FROM administradores WHERE id_admin = ?"
    : "SELECT nombres, apellidos, correo, telefono, rol FROM vendedores WHERE id_vendedor = ?";

$stmt = $conn->prepare($sql);
$stmt->execute([$id]);
$usuario = $stmt->fetch();


if (!$usuario) {
    die("Usuario no encontrado");
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mi Perfil</title>
    <style>
        body {
            font-family: 'Lucida Sans', sans-serif;
            background-color: #f0f8ff;
            color: #000;
            padding: 30px;
        }
        .perfil-container {
            max-width: 500px;
            margin: auto;
            padding: 25px;
            border: 2px solid #000;
            border-radius: 15px;
            background-color: #e6f7ff;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #007acc;
        }
        .dato {
            margin: 10px 0;
            padding: 10px;
            background: #fff;
            border: 1px solid #ccc;
            border-radius: 10px;
        }
        .label {
            font-weight: bold;
            color: #007acc;
        }
    </style>
</head>
<body>
    <div class="perfil-container">
        <h2>Mi Perfil</h2>
        <div class="dato"><span class="label">Nombres:</span> <?= htmlspecialchars($usuario['nombres']) ?></div>
        <div class="dato"><span class="label">Apellidos:</span> <?= htmlspecialchars($usuario['apellidos']) ?></div>
        <div class="dato"><span class="label">Correo:</span> <?= htmlspecialchars($usuario['correo']) ?></div>
        <div class="dato"><span class="label">Teléfono:</span> <?= htmlspecialchars($usuario['telefono']) ?></div>
        <div class="dato"><span class="label">Rol:</span> <?= htmlspecialchars($usuario['rol']) ?></div>
    </div>
</body>
</html>

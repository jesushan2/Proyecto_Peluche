<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<div class="form-container">
    <h2>Listado de Franquicias</h2>

    <?php if (!empty($_SESSION['mensaje'])): ?>
        <div class="mensaje"><?= htmlspecialchars($_SESSION['mensaje']); unset($_SESSION['mensaje']); ?></div>
    <?php elseif (!empty($_SESSION['error'])): ?>
        <div class="error"><?= htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <table style="width:100%; border-collapse: collapse; margin-top: 20px;">
        <thead>
            <tr style="background-color: #f5f5f5;">
                <th>ID</th>
                <th>Nombre</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($franquicias as $f): ?>
                <tr style="text-align: center; border-bottom: 1px solid #ccc;">
                    <td><?= (int) $f['id_franquicia'] ?></td>
                    <td><?= htmlspecialchars($f['nombre_fran']) ?></td>
                    <td><?= (int) $f['estado_activo'] === 1 ? 'Activo' : 'Inactivo' ?></td>
                    <td>
                        <a href="/PROYECTO_PELUCHE/admin/franquicia/editarFranquicia?id=<?= (int) $f['id_franquicia'] ?>"
                           target="iframe-contenido" style="color: #007bff; margin-right: 10px;">Editar</a>
                        <a href="/PROYECTO_PELUCHE/admin/franquicia/eliminarFranquicia?id=<?= (int) $f['id_franquicia'] ?>"
                           onclick="return confirm('¿Deseas eliminar esta franquicia?')"
                           style="color: red;">Eliminar</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<link rel="stylesheet" href="/PROYECTO_PELUCHE/STYLE/GENERAL_LISTA.css">

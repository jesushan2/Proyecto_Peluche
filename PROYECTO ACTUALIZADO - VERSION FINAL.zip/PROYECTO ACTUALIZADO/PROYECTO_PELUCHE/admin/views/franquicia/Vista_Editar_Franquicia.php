<?php
if (session_status() === PHP_SESSION_NONE) session_start();
?>

<div class="form-container">
    <h2>Editar Franquicia</h2>

    <form method="post" action="/PROYECTO_PELUCHE/admin/franquicia/procesarActualizacion">
        <input type="hidden" name="id_franquicia" value="<?= (int) $franquicia['id_franquicia'] ?>">

        <label>Nombre de la franquicia:</label>
        <input type="text" name="nombre_fran" value="<?= htmlspecialchars($franquicia['nombre_fran']) ?>" required>

        <label>Estado:</label>
        <select name="estado_activo" required>
            <option value="1" <?= (int)$franquicia['estado_activo'] === 1 ? 'selected' : '' ?>>Activo</option>
            <option value="0" <?= (int)$franquicia['estado_activo'] === 0 ? 'selected' : '' ?>>Inactivo</option>
        </select>

        <button type="submit">Guardar Cambios</button>
    </form>
</div>

<link rel="stylesheet" href="/PROYECTO_PELUCHE/STYLE/GENERAL_REGISTRO.css">

<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<div class="form-container">
    <h2>Historial de Cambios de Reserva</h2>

    <table style="width:100%; border-collapse: collapse; margin-top: 20px;">
        <thead>
            <tr style="background-color: #f5f5f5;">
                <th>ID</th>
                <th>Estado Anterior</th>
                <th>Estado Nuevo</th>
                <th>Fecha de Cambio</th>
                <th>Modificado por</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($historial)): ?>
                <?php foreach ($historial as $registro): ?>
                    <tr style="text-align: center; border-bottom: 1px solid #ccc;">
                        <td><?= $registro['id_historial'] ?></td>
                        <td><?= $registro['estado_anterior'] ?></td>
                        <td><?= $registro['estado_nuevo'] ?></td>
                        <td><?= $registro['fecha_cambio'] ?></td>
                        <td>
                            <?= $registro['admin'] ? 'Admin: ' . $registro['admin'] : 'Vendedor: ' . $registro['vendedor'] ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="5">No hay historial para esta reserva.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<link rel="stylesheet" href="/PROYECTO_PELUCHE/STYLE/GENERAL_LISTA.css">
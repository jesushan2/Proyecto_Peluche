<?php
require_once __DIR__ . '/../../../config/database.php';

$conn = Database::connect();

$query = "SELECT * FROM vista_resumen_reservas ORDER BY fecha_reserva DESC";
$stmt = $conn->query($query);
$reservas = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reservas Registradas</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 15px;
        }

        th, td {
            padding: 8px 12px;
            border: 1px solid #ddd;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
        }

        input[type="text"] {
            padding: 5px;
            width: 250px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <h2>Listado de Reservas Activas</h2>

    <label for="buscador">Buscar por cliente:</label>
    <input type="text" id="buscador" placeholder="Escribe el nombre del cliente...">

    <table id="tablaReservas">
        <thead>
            <tr>
                <th>ID Reserva</th>
                <th>Cliente</th>
                <th>Producto</th>
                <th>Cantidad</th>
                <th>Precio Unitario</th>
                <th>Subtotal</th>
                <th>Estado</th>
                <th>Fecha</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($reservas as $reserva): ?>
                <tr>
                    <td><?= $reserva['id_reserva'] ?></td>
                    <td><?= htmlspecialchars($reserva['nombre_usuario']) ?></td>
                    <td><?= htmlspecialchars($reserva['producto']) ?></td>
                    <td><?= $reserva['cantidad'] ?></td>
                    <td><?= number_format($reserva['precio_unitario'], 2) ?></td>
                    <td><?= number_format($reserva['subtotal'], 2) ?></td>
                    <td><?= htmlspecialchars($reserva['estado_reserva']) ?></td>
                    <td><?= $reserva['fecha_reserva'] ?></td>
                    <td><?= number_format($reserva['total'], 2) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <script>
        document.getElementById("buscador").addEventListener("keyup", function () {
            let filtro = this.value.toLowerCase();
            let filas = document.querySelectorAll("#tablaReservas tbody tr");

            filas.forEach(function (fila) {
                let nombre = fila.cells[1].textContent.toLowerCase();
                fila.style.display = nombre.includes(filtro) ? "" : "none";
            });
        });
    </script>
</body>
</html>

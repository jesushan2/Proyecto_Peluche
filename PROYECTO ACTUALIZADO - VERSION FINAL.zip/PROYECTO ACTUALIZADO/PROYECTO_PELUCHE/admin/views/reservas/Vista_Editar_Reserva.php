<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<div class="form-container">
    <h2>Editar Reserva #<?= $reserva['id_reserva'] ?></h2>

    <?php if (!empty($_SESSION['mensaje'])): ?>
        <div class="mensaje"><?= $_SESSION['mensaje']; unset($_SESSION['mensaje']); ?></div>
    <?php elseif (!empty($_SESSION['error'])): ?>
        <div class="error"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <form method="POST" action="/PROYECTO_PELUCHE/admin/reserva/procesarEdicion">
        <input type="hidden" name="id_reserva" value="<?= $reserva['id_reserva'] ?>">

        <label for="id_vendedor">Asignar Vendedor:</label>
        <select name="id_vendedor" required>
            <option value="">Seleccione un vendedor</option>
            <?php foreach ($vendedores as $v): ?>
                <option value="<?= $v['id_vendedor'] ?>" <?= $reserva['id_vendedor'] == $v['id_vendedor'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($v['nombres']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="id_estado">Estado de la Reserva:</label>
        <select name="id_estado" required>
            <option value="">Seleccione un estado</option>
            <?php foreach ($estados as $e): ?>
                <option value="<?= $e['id_estado'] ?>" <?= $reserva['id_estado'] == $e['id_estado'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($e['nombre_est']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <button type="submit">Guardar Cambios</button>
    </form>
</div>
<link rel="stylesheet" href="/PROYECTO_PELUCHE/STYLE/GENERAL_REGISTRO.css">
<?php if (session_status() === PHP_SESSION_NONE)
    session_start(); ?>
<div class="form-container">
    <h2>Listado de Reservas</h2>

    <?php if (!empty($_SESSION['mensaje'])): ?>
        <div class="mensaje"><?= $_SESSION['mensaje'];
        unset($_SESSION['mensaje']); ?></div>
    <?php elseif (!empty($_SESSION['error'])): ?>
        <div class="error"><?= $_SESSION['error'];
        unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <table style="width:100%; border-collapse: collapse; margin-top: 20px;">
        <thead>
            <tr style="background-color: #f5f5f5;">
                <th>ID</th>
                <th>Cliente</th>
                <th>Estado</th>
                <th>Vendedor</th>
                <th>Fecha</th>
                <th>Total</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($reservas as $res): ?>
                <tr style="text-align: center; border-bottom: 1px solid #ccc;">
                    <td><?= $res['id_reserva'] ?></td>
                    <td><?= htmlspecialchars($res['nombre_usuario']) ?></td>
                    <td><?= htmlspecialchars($res['nombre_estado']) ?></td>
                    <td><?= $res['nombre_vendedor'] ?? 'No asignado' ?></td>
                    <td><?= $res['fecha_reserva'] ?></td>
                    <td>S/ <?= number_format($res['total'], 2) ?></td>
                    <td>
                        <a href="/PROYECTO_PELUCHE/admin/reserva/mostrarFormularioEdicion/<?= $res['id_reserva'] ?>"
                            target="iframe-contenido" style="color: #007bff; margin-right: 8px;">Editar</a>

                        <a href="/PROYECTO_PELUCHE/admin/reserva/eliminarReserva/<?= $res['id_reserva'] ?>"
                            onclick="return confirm('¿Estás seguro de eliminar esta reserva?')"
                            style="color: red; margin-right: 8px;">Eliminar</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<link rel="stylesheet" href="/PROYECTO_PELUCHE/STYLE/GENERAL_LISTA.css">
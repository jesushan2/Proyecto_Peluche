<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<div class="form-container">
    <h2>Historial de Reservas</h2>

    <input type="text" id="busqueda-reserva" placeholder="Buscar por ID de reserva" style="margin-bottom: 15px; padding: 8px; width: 100%; max-width: 300px; border: 1px solid #ccc; border-radius: 4px;">

    <table id="tabla-reservas" style="width:100%; border-collapse: collapse; margin-top: 10px;">
        <thead>
            <tr style="background-color: #f5f5f5;">
                <th>ID</th>
                <th>Cliente</th>
                <th>Estado</th>
                <th>Vendedor</th>
                <th>Fecha</th>
                <th>Total</th>
                <th>Historial</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($reservas as $res): ?>
                <tr style="text-align: center; border-bottom: 1px solid #ccc;">
                    <td><?= $res['id_reserva'] ?></td>
                    <td><?= htmlspecialchars($res['nombre_usuario']) ?></td>
                    <td><?= htmlspecialchars($res['nombre_estado']) ?></td>
                    <td><?= $res['nombre_vendedor'] ?? 'No asignado' ?></td>
                    <td><?= $res['fecha_reserva'] ?></td>
                    <td>S/ <?= number_format($res['total'], 2) ?></td>
                    <td>
                        <a href="/PROYECTO_PELUCHE/admin/reserva/verHistorial/<?= $res['id_reserva'] ?>" 
                           target="iframe-contenido" style="color: #28a745;">Historial</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<link rel="stylesheet" href="/PROYECTO_PELUCHE/STYLE/GENERAL_LISTA.css">

<script>
document.getElementById('busqueda-reserva').addEventListener('keyup', function() {
    const filtro = this.value.trim();
    const filas = document.querySelectorAll("#tabla-reservas tbody tr");

    filas.forEach(fila => {
        const id = fila.cells[0].textContent.trim();
        fila.style.display = id.includes(filtro) ? "" : "none";
    });
});
</script>


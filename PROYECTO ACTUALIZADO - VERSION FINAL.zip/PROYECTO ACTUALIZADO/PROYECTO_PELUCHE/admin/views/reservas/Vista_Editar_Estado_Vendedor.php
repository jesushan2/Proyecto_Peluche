<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<div class="form-container">
    <h2>Cambiar Estado de Reserva</h2>

    <form method="post" action="/PROYECTO_PELUCHE/admin/reserva/procesarCambioEstadoVendedor">
        <input type="hidden" name="id_reserva" value="<?= htmlspecialchars($reserva['id_reserva']) ?>">

        <div class="form-group">
            <label for="estado">Estado Actual:</label>
            <input type="text" class="form-control" value="<?= htmlspecialchars($reserva['nombre_estado']) ?>" disabled>
        </div>

        <div class="form-group">
            <label for="id_estado">Nuevo Estado:</label>
            <select class="form-control" name="id_estado" id="id_estado" required>
                <?php foreach ($estados as $estado): ?>
                    <option value="<?= $estado['id_estado'] ?>"><?= htmlspecialchars($estado['nombre_est']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
    </form>
</div>

<link rel="stylesheet" href="/PROYECTO_PELUCHE/STYLE/GENERAL_REGISTRO.css">

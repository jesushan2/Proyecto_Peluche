<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<div class="form-container">
    <h2>Mis Reservas Asignadas</h2>

    <?php if (!empty($reservas)): ?>
        <table class="tabla-estilizada">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Cliente</th>
                    <th>Fecha</th>
                    <th>Total</th>
                    <th>Estado</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($reservas as $reserva): ?>
                    <tr>
                        <td><?= $reserva['id_reserva'] ?></td>
                        <td><?= htmlspecialchars($reserva['nombre_usuario']) ?></td>
                        <td><?= $reserva['fecha_reserva'] ?></td>
                        <td>S/. <?= number_format($reserva['total'], 2) ?></td>
                        <td><?= htmlspecialchars($reserva['nombre_estado']) ?></td>
                        <td>
                        <a href="/PROYECTO_PELUCHE/admin/reserva/mostrarFormularioCambioEstadoVendedor/<?= $reserva['id_reserva'] ?>" class="btn btn-warning btn-sm">Editar Estado</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No tienes reservas asignadas.</p>
    <?php endif; ?>
</div>
<link rel="stylesheet" href="/PROYECTO_PELUCHE/STYLE/GENERAL_LISTA.css">

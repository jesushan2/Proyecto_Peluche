<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<div class="form-container">
    <h2>Editar Producto</h2>

    <form method="post" action="/PROYECTO_PELUCHE/admin/producto/procesarEdicionProducto">
        <input type="hidden" name="id_producto" value="<?= $producto['id_producto'] ?>">

        <label>Franquicia:</label>
        <select name="id_franquicia" required>
            <option value="">Seleccione</option>
            <?php foreach ($franquicias as $f): ?>
                <option value="<?= $f['id_franquicia'] ?>" <?= $f['id_franquicia'] == $producto['id_franquicia'] ? 'selected' : '' ?>>
                    <?= $f['nombre_fran'] ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label>Nombre:</label>
        <input type="text" name="nombre_prod" value="<?= htmlspecialchars($producto['nombre_prod']) ?>" required>

        <label>Descripción:</label>
        <input type="text" name="descripcion" value="<?= htmlspecialchars($producto['descripcion']) ?>" required>

        <label>Altura:</label>
        <input type="text" name="altura" value="<?= htmlspecialchars($producto['altura']) ?>" required>

        <label>Color:</label>
        <input type="text" name="color" value="<?= htmlspecialchars($producto['color']) ?>" required>

        <label>Stock:</label>
        <input type="number" name="stock" value="<?= $producto['stock'] ?>" required>

        <label>Precio:</label>
        <input type="number" step="0.01" name="precio" value="<?= $producto['precio'] ?>" required>

        <label>Imagen (URL):</label>
        <input type="text" name="imagen" value="<?= htmlspecialchars($producto['imagen']) ?>" required>

        <button type="submit">Guardar Cambios</button>
    </form>
</div>
<link rel="stylesheet" href="/PROYECTO_PELUCHE/STYLE/GENERAL_REGISTRO.css">
<script src="/PROYECTO_PELUCHE/JS/JS_DE_REGISTRO_PRODUCTO.js" defer></script>
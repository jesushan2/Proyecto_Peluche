<?php
require_once __DIR__ . '/../../../config/database.php';

$conn = Database::connect();

$sql = "SELECT * FROM vista_productos WHERE estado_activo = 1 ORDER BY id_producto DESC";
$stmt = $conn->query($sql);
$productos = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Vista de Productos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
        }
        input[type="text"] {
            padding: 8px;
            width: 300px;
            margin-bottom: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        img {
            width: 80px;
            height: auto;
        }
    </style>
</head>
<body>
    <h2>Listado Completo de Productos</h2>

    <input type="text" id="buscador" placeholder="Buscar por nombre o franquicia...">

    <table id="tabla-productos">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Altura</th>
                <th>Color</th>
                <th>Stock</th>
                <th>Precio</th>
                <th>Imagen</th>
                <th>Franquicia</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($productos as $producto): ?>
                <tr>
                    <td><?= $producto['id_producto'] ?></td>
                    <td><?= htmlspecialchars($producto['nombre_prod']) ?></td>
                    <td><?= htmlspecialchars($producto['descripcion']) ?></td>
                    <td><?= htmlspecialchars($producto['altura']) ?></td>
                    <td><?= htmlspecialchars($producto['color']) ?></td>
                    <td><?= $producto['stock'] ?></td>
                    <td>S/ <?= number_format($producto['precio'], 2) ?></td>
                    <td><img src="/PROYECTO_PELUCHE/image/<?= htmlspecialchars($producto['imagen']) ?>" alt="Producto">                    </td>
                    <td><?= htmlspecialchars($producto['nombre_franquicia']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <script>
        const input = document.getElementById('buscador');
        const filas = document.querySelectorAll('#tabla-productos tbody tr');

        input.addEventListener('input', () => {
            const filtro = input.value.toLowerCase();
            filas.forEach(fila => {
                const texto = fila.textContent.toLowerCase();
                fila.style.display = texto.includes(filtro) ? '' : 'none';
            });
        });
    </script>
</body>
</html>

<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<div class="form-container">
    <h2>Registrar Producto</h2>

    <?php if (!empty($_SESSION['mensaje'])): ?>
        <div class="success"><?= htmlspecialchars($_SESSION['mensaje']); unset($_SESSION['mensaje']); ?></div>
    <?php elseif (!empty($_SESSION['error'])): ?>
        <div class="error"><?= htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <form method="POST" action="/PROYECTO_PELUCHE/admin/producto/procesarRegistroProducto" id="formRegistroProducto">
        <label for="id_franquicia">Franquicia:</label>
        <select name="id_franquicia" required>
            <option value="">Seleccione una franquicia</option>
            <?php foreach ($franquicias as $f): ?>
                <option value="<?= htmlspecialchars($f['id_franquicia']) ?>"><?= htmlspecialchars($f['nombre_fran']) ?></option>
            <?php endforeach; ?>
        </select>

        <input type="text" name="nombre_prod" placeholder="Nombre del producto" required>
        <input type="text" name="descripcion" placeholder="Descripción" required>
        <input type="text" name="altura" placeholder="Altura" required>
        <input type="text" name="color" placeholder="Color" required>
        <input type="number" name="stock" placeholder="Stock (máx 9999)" maxlength="4" required>
        <input type="text" name="precio" placeholder="Precio (ej. 10.00)" required>
        <input type="text" name="imagen" placeholder="Ruta de la imagen" required>
        
        <button type="submit">Registrar Producto</button>
    </form>
</div>
<link rel="stylesheet" href="/PROYECTO_PELUCHE/STYLE/GENERAL_REGISTRO.css">
<script src="/PROYECTO_PELUCHE/JS/JS_DE_REGISTRO_PRODUCTO.js" defer></script>

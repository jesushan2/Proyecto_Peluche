<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<div class="form-container">
    <h2>Listado de Productos</h2>

    <?php if (!empty($_SESSION['mensaje'])): ?>
        <div class="mensaje"><?= $_SESSION['mensaje']; unset($_SESSION['mensaje']); ?></div>
    <?php elseif (!empty($_SESSION['error'])): ?>
        <div class="error"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <table style="width:100%; border-collapse: collapse; margin-top: 20px;">
        <thead>
            <tr style="background-color: #f5f5f5;">
                <th>ID</th>
                <th>Nombre</th>
                <th>Franquicia</th>
                <th>Stock</th>
                <th>Precio</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($productos as $p): ?>
                <tr style="text-align: center; border-bottom: 1px solid #ccc;">
                    <td><?= $p['id_producto'] ?></td>
                    <td><?= htmlspecialchars($p['nombre_prod']) ?></td>
                    <td><?= $p['nombre_fran'] ?></td>
                    <td><?= $p['stock'] ?></td>
                    <td>S/ <?= number_format($p['precio'], 2) ?></td>
                    <td>
                        <a href="/PROYECTO_PELUCHE/admin/producto/mostrarFormularioEdicion/<?= $p['id_producto'] ?>"
                           target="iframe-contenido" style="color: #007bff;">Editar</a>
                           <a href="/PROYECTO_PELUCHE/admin/producto/eliminarProducto?id=<?= $p['id_producto'] ?>"
       onclick="return confirm('¿Estás seguro de eliminar este producto?')"
       style="color: red;">Eliminar</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<link rel="stylesheet" href="/PROYECTO_PELUCHE/STYLE/GENERAL_LISTA.css">

<?php
require_once __DIR__ . '/../models/ADReservaDAO.php';
require_once __DIR__ . '/../../app/models/LoggerWeb.php';

class ADReservaController {
    private ADReservaDAO $modelo;
    private LoggerWeb $logger;

    public function __construct() {
        if (session_status() === PHP_SESSION_NONE)
            session_start();
        $this->modelo = new ADReservaDAO();
        $this->logger = new LoggerWeb();
    }

    public function mostrarReservasVendedor()
    {
        if ($_SESSION['usuario_rol'] !== 'vendedor') {
            header("Location: /PROYECTO_PELUCHE/admin/login/index");
            exit;
        }
    
        $id_vendedor = $_SESSION['usuario_id'];
        $reservas = $this->modelo->obtenerReservasPorVendedor($id_vendedor);
    
        $this->logger->registrar($id_vendedor, 'Listar', 'Listado de reservas asignadas al vendedor mostrado');
    
        require_once __DIR__ . '/../views/reservas/Vista_Reservas_Vendedor.php';
    }
    
    public function mostrarFormularioCambioEstadoVendedor($id) {
        if ($_SESSION['usuario_rol'] !== 'vendedor') {
            header("Location: /PROYECTO_PELUCHE/admin/login/index");
            exit;
        }
    
        $reserva = $this->modelo->obtenerReservaPorId($id);
        $estados = $this->modelo->obtenerEstados();
    
        if ($reserva['id_vendedor'] != $_SESSION['usuario_id']) {
            $_SESSION['error'] = 'No tienes permiso para editar esta reserva.';
            header("Location: /PROYECTO_PELUCHE/admin/reserva/mostrarReservasVendedor");
            exit;
        }
    
        $this->logger->registrar($_SESSION['usuario_id'], 'Acceso', "Formulario de cambio de estado para reserva #$id accedido por vendedor");
    
        require_once __DIR__ . '/../views/reservas/Vista_Editar_Estado_Vendedor.php';
    }
    
    public function procesarCambioEstadoVendedor() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $_POST['id_reserva'] ?? '';
            $id_estado_nuevo = $_POST['id_estado'] ?? '';
    
            if (!$id || !$id_estado_nuevo) {
                $_SESSION['error'] = 'Campos incompletos.';
                header("Location: /PROYECTO_PELUCHE/admin/reserva/mostrarReservasVendedor");
                exit;
            }
    
            $reserva = $this->modelo->obtenerReservaPorId($id);
            if ($reserva['id_vendedor'] != $_SESSION['usuario_id']) {
                $_SESSION['error'] = 'No tienes permiso para modificar esta reserva.';
                header("Location: /PROYECTO_PELUCHE/admin/reserva/mostrarReservasVendedor");
                exit;
            }
    
            $estadoAnterior = $this->modelo->editarReserva($id, $id_estado_nuevo, $reserva['id_vendedor']);
    
            if ($estadoAnterior !== false) {
                $this->modelo->registrarHistorial($id, $estadoAnterior, $id_estado_nuevo, null, $_SESSION['usuario_id']);
                $_SESSION['mensaje'] = 'Estado actualizado correctamente.';
    
                $this->logger->registrar(
                    $_SESSION['usuario_id'],
                    'Actualizar',
                    "Vendedor actualizó estado de reserva #$id de $estadoAnterior a $id_estado_nuevo"
                );
            } else {
                $_SESSION['error'] = 'Error al actualizar estado.';
                $this->logger->registrar(
                    $_SESSION['usuario_id'],
                    'Error',
                    "Vendedor falló al actualizar estado de reserva #$id"
                );
            }
    
            header("Location: /PROYECTO_PELUCHE/admin/reserva/mostrarReservasVendedor");
            exit;
        }
    }
    
    public function mostrarListadoReservas() {
        $reservas = $this->modelo->obtenerTodasReservas();
        $this->logger->registrar($_SESSION['usuario_id'] ?? null, 'Listar', 'Listado de reservas mostrado');
        require_once __DIR__ . '/../views/reservas/Vista_Listado_Reservas.php';
    }

    public function verVistaReservas() {
        $this->logger->registrar($_SESSION['usuario_id'] ?? null, 'Ver', 'Vista reservas visualizada');
        require_once __DIR__ . '/../views/reservas/Vista_Reservas.php';
    }

    public function mostrarFormularioEdicion($id) {
        $reserva = $this->modelo->obtenerReservaPorId($id);
        $estados = $this->modelo->obtenerEstados();
        $vendedores = $this->modelo->obtenerVendedores();
        $this->logger->registrar($_SESSION['usuario_id'] ?? null, 'Editar', "Formulario de edición abierto para reserva ID: $id");
        require_once __DIR__ . '/../views/reservas/Vista_Editar_Reserva.php';
    }

    public function procesarEdicion() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $_POST['id_reserva'] ?? '';
            $id_estado_nuevo = $_POST['id_estado'] ?? '';
            $id_vendedor = $_POST['id_vendedor'] ?? null;

            if (!$id || !$id_estado_nuevo) {
                $_SESSION['error'] = 'Todos los campos obligatorios deben ser completados';
                header("Location: /PROYECTO_PELUCHE/admin/reserva/mostrarListadoReservas");
                exit;
            }

            $estadoAnterior = $this->modelo->editarReserva((int)$id, (int)$id_estado_nuevo, $id_vendedor);

            if ($estadoAnterior !== false) {
                $id_admin = $_SESSION['usuario_rol'] === 'admin' ? $_SESSION['usuario_id'] : null;
                $id_vend = $_SESSION['usuario_rol'] === 'vendedor' ? $_SESSION['usuario_id'] : null;

                $this->modelo->registrarHistorial((int)$id, (int)$estadoAnterior, (int)$id_estado_nuevo, $id_admin, $id_vend);

                $usuarioId = $this->modelo->obtenerIdUsuarioPorReserva((int)$id);
                $estadoAnteriorNombre = $this->modelo->obtenerNombreEstadoPorId($estadoAnterior);
                $estadoNuevoNombre = $this->modelo->obtenerNombreEstadoPorId($id_estado_nuevo);

                if ($usuarioId && $estadoAnteriorNombre && $estadoNuevoNombre) {
                    $mensaje = "Tu reserva #$id ha cambiado de estado: $estadoAnteriorNombre → $estadoNuevoNombre.";
                    $this->modelo->registrarNotificacion($usuarioId, (int)$id, $mensaje);
                }

                $_SESSION['mensaje'] = 'Reserva actualizada correctamente.';
                $this->logger->registrar($_SESSION['usuario_id'] ?? null, 'Actualizar', "Reserva #$id actualizada de estado $estadoAnterior a $id_estado_nuevo");
            } else {
                $_SESSION['error'] = 'Error al actualizar la reserva.';
                $this->logger->registrar($_SESSION['usuario_id'] ?? null, 'Error', "Fallo al actualizar reserva ID: $id");
            }

            header("Location: /PROYECTO_PELUCHE/admin/reserva/mostrarListadoReservas");
            exit;
        }
    }

    public function mostrarSoloHistorialReservas() {
        $reservas = $this->modelo->obtenerTodasReservas();
        $this->logger->registrar($_SESSION['usuario_id'] ?? null, 'Historial', 'Vista de historial de reservas accedida');
        require_once __DIR__ . '/../views/reservas/Vista_Listado_Historial_Reservas.php';
    }

    public function verHistorial($id) {
        $historial = $this->modelo->obtenerHistorialPorReserva((int)$id);
        $this->logger->registrar($_SESSION['usuario_id'] ?? null, 'Historial', "Historial accedido para reserva ID: $id");
        require_once __DIR__ . '/../views/reservas/Vista_Historial_Reserva.php';
    }

    public function eliminarReserva($id) {
        $resultado = $this->modelo->desactivarReserva((int)$id);

        $this->logger->registrar(
            $_SESSION['usuario_id'] ?? null,
            $resultado ? 'Eliminar' : 'Error',
            $resultado ? "Reserva ID $id eliminada" : "Error al eliminar reserva ID: $id"
        );

        $_SESSION[$resultado ? 'mensaje' : 'error'] = $resultado ? 'Reserva eliminada' : 'Error al eliminar';
        header("Location: /PROYECTO_PELUCHE/admin/reserva/mostrarListadoReservas");
        exit;
    }
}

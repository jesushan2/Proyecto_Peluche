<?php
if (session_status() === PHP_SESSION_NONE) session_start();

require_once __DIR__ . '/../models/ADLoginDAO.php';
require_once __DIR__ . '/../../app/models/LoggerWeb.php';

class ADLoginController {
    private ADLoginDAO $modelo;
    private LoggerWeb $logger;

    public function __construct() {
        $this->modelo = new ADLoginDAO();
        $this->logger = new LoggerWeb();
    }

    public function index() {
        $this->logger->registrar(null, 'Vista', 'Vista de login abierta');
        require_once __DIR__ . '/../views/login/Vista_Login.php';
    }

    public function autenticar() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $correo = $_POST['correo'] ?? '';
            $clave = $_POST['clave'] ?? '';

            $usuario = $this->modelo->obtenerUsuarioPorCorreo($correo);

            if ($usuario && password_verify($clave, $usuario['clave'])) {
                $_SESSION['usuario_id']     = $usuario['id'];
                $_SESSION['usuario_nombre'] = $usuario['nombres'];
                $_SESSION['usuario_rol']    = $usuario['rol'];

                $this->logger->registrar($usuario['id'], 'Login', "Acceso exitoso como {$usuario['rol']}");
                header("Location: /PROYECTO_PELUCHE/admin/inicio/index");
                exit;
            } else {
                $this->logger->registrar(null, 'Error', "Intento fallido de login con correo: $correo");
                $_SESSION['error'] = "Correo o contraseña incorrectos.";
                header("Location: /PROYECTO_PELUCHE/admin/login/index");
                exit;
            }
        }
    }

    public function cerrarSesion() {
        $id = $_SESSION['usuario_id'] ?? null;
        $this->logger->registrar($id, 'Logout', 'Cierre de sesión');

        session_unset();
        session_destroy();
        header("Location: /PROYECTO_PELUCHE/admin/login/index");
        exit;
    }
}

<?php
require_once __DIR__ . '/../models/ADLogDAO.php';

class ADLogController {
    private ADLogDAO $modelo;

    public function __construct() {
        $this->modelo = new ADLogDAO();
    }

    public function index() {
        $logs = $this->modelo->obtenerTodosLogs();
        require_once __DIR__ . '/../views/logs/Vista_Listado_Logs.php';
    }
}

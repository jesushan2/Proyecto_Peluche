<?php
require_once __DIR__ . '/../models/ADProductoDAO.php';
require_once __DIR__ . '/../../app/models/LoggerWeb.php';

class ADProductoController {
    private ADProductoDAO $modelo;
    private LoggerWeb $logger;

    public function __construct() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $this->modelo = new ADProductoDAO();
        $this->logger = new LoggerWeb();
    }

    public function mostrarFormularioProducto() {
        $franquicias = $this->modelo->obtenerFranquicias();
        $this->logger->registrar($_SESSION['usuario_id'] ?? null, 'Formulario', 'Accedió al formulario de registro de producto');
        require_once __DIR__ . '/../views/productos/Vista_Registro_Producto.php';
    }

    public function verVistaProductos() {
        $this->logger->registrar($_SESSION['usuario_id'] ?? null, 'Vista', 'Vista general de productos visualizada');
        require_once __DIR__ . '/../views/productos/Vista_Productos.php';
    }

    public function procesarRegistroProducto() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $datos = [
                'id_franquicia' => $_POST['id_franquicia'] ?? '',
                'nombre_prod' => trim($_POST['nombre_prod'] ?? ''),
                'descripcion' => trim($_POST['descripcion'] ?? ''),
                'altura' => trim($_POST['altura'] ?? ''),
                'color' => trim($_POST['color'] ?? ''),
                'stock' => $_POST['stock'] ?? '',
                'precio' => $_POST['precio'] ?? '',
                'imagen' => trim($_POST['imagen'] ?? '')
            ];

            if (in_array('', $datos, true)) {
                $_SESSION['error'] = 'Todos los campos son obligatorios.';
                $this->logger->registrar($_SESSION['usuario_id'] ?? null, 'Error', 'Registro de producto fallido por campos vacíos');
                header("Location: /PROYECTO_PELUCHE/admin/producto/mostrarFormularioProducto");
                exit;
            }

            $registrado = $this->modelo->registrarProducto($datos);
            $this->logger->registrar(
                $_SESSION['usuario_id'] ?? null,
                $registrado ? 'Registro' : 'Error',
                $registrado ? 'Producto registrado correctamente' : 'Error al registrar producto'
            );

            $_SESSION[$registrado ? 'mensaje' : 'error'] = $registrado
                ? 'Producto registrado correctamente.'
                : 'Error al registrar el producto.';

            header("Location: /PROYECTO_PELUCHE/admin/producto/mostrarFormularioProducto");
            exit;
        }
    }

    public function mostrarListadoProductos() {
        $productos = $this->modelo->obtenerTodosProductos();
        $this->logger->registrar($_SESSION['usuario_id'] ?? null, 'Listado', 'Listado de productos mostrado');
        require_once __DIR__ . '/../views/productos/Vista_Listado_Productos.php';
    }

    public function eliminarProducto() {
        if (!isset($_GET['id'])) {
            $_SESSION['error'] = 'ID del producto no proporcionado.';
            $this->logger->registrar($_SESSION['usuario_id'] ?? null, 'Error', 'Intento de eliminación sin ID');
            header("Location: /PROYECTO_PELUCHE/admin/producto/mostrarFormularioProducto");
            exit;
        }

        $id = intval($_GET['id']);
        $eliminado = $this->modelo->desactivarProducto($id);

        $this->logger->registrar(
            $_SESSION['usuario_id'] ?? null,
            $eliminado ? 'Eliminar' : 'Error',
            $eliminado ? "Producto ID $id eliminado correctamente" : "Error al eliminar producto ID $id"
        );

        $_SESSION[$eliminado ? 'mensaje' : 'error'] = $eliminado
            ? 'Producto eliminado correctamente.'
            : 'Error al eliminar el producto.';

        header("Location: /PROYECTO_PELUCHE/admin/producto/mostrarFormularioProducto");
        exit;
    }

    public function mostrarFormularioEdicion($id) {
        $producto = $this->modelo->obtenerProductoPorId($id);
        $franquicias = $this->modelo->obtenerFranquicias();
        $this->logger->registrar($_SESSION['usuario_id'] ?? null, 'Formulario', "Formulario de edición abierto para producto ID: $id");
        require_once __DIR__ . '/../views/productos/Vista_Editar_Producto.php';
    }

    public function procesarEdicionProducto() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $_POST['id_producto'] ?? '';
            $datos = [
                'id_franquicia' => $_POST['id_franquicia'] ?? '',
                'nombre_prod'   => trim($_POST['nombre_prod'] ?? ''),
                'descripcion'   => trim($_POST['descripcion'] ?? ''),
                'altura'        => trim($_POST['altura'] ?? ''),
                'color'         => trim($_POST['color'] ?? ''),
                'stock'         => $_POST['stock'] ?? '',
                'precio'        => $_POST['precio'] ?? '',
                'imagen'        => trim($_POST['imagen'] ?? '')
            ];

            if (!$id || in_array('', $datos, true)) {
                $_SESSION['error'] = 'Todos los campos son obligatorios.';
                $this->logger->registrar($_SESSION['usuario_id'] ?? null, 'Error', 'Edición fallida por campos vacíos');
                header("Location: /PROYECTO_PELUCHE/admin/producto/mostrarListadoProductos");
                exit;
            }

            $actualizado = $this->modelo->editarProducto((int)$id, $datos);

            $this->logger->registrar(
                $_SESSION['usuario_id'] ?? null,
                $actualizado ? 'Actualizar' : 'Error',
                $actualizado ? "Producto ID $id actualizado" : "Error al actualizar producto ID $id"
            );

            $_SESSION[$actualizado ? 'mensaje' : 'error'] = $actualizado
                ? 'Producto actualizado correctamente.'
                : 'Error al actualizar el producto.';

            header("Location: /PROYECTO_PELUCHE/admin/producto/mostrarListadoProductos");
            exit;
        }
    }
}

<?php
require_once __DIR__ . '/../models/ADUsuarioClienteDAO.php';
require_once __DIR__ . '/../../app/models/LoggerWeb.php';

class ADUsuarioClienteController {
    private ADUsuarioClienteDAO $modelo;
    private LoggerWeb $logger;

    public function __construct() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $this->modelo = new ADUsuarioClienteDAO();
        $this->logger = new LoggerWeb();
    }

    public function listarClientes() {
        $usuarios = $this->modelo->obtenerTodos();
        $this->logger->registrar($_SESSION['usuario_admin']['id'] ?? null, 'Listar', 'Listado de clientes visualizado');
        require_once __DIR__ . '/../views/usuarios/Vista_Listado_Clientes.php';
    }

    public function editarUsuario() {
        if (!isset($_GET['id'])) {
            $_SESSION['error'] = 'ID no proporcionado.';
            header("Location: /PROYECTO_PELUCHE/admin/usuarioCliente/listarClientes");
            exit;
        }

        $usuario = $this->modelo->obtenerPorId((int)$_GET['id']);
        if (!$usuario) {
            $_SESSION['error'] = 'Usuario no encontrado.';
            header("Location: /PROYECTO_PELUCHE/admin/usuarioCliente/listarClientes");
            exit;
        }

        $this->logger->registrar($_SESSION['usuario_admin']['id'] ?? null, 'Editar', 'Formulario de edición de cliente abierto');
        require_once __DIR__ . '/../views/usuarios/Vista_Editar_Cliente.php';
    }

    public function procesarEdicion() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = intval($_POST['id_usuario'] ?? 0);
            $datos = [
                'nombres'   => trim($_POST['nombres'] ?? ''),
                'apellidos' => trim($_POST['apellidos'] ?? ''),
                'telefono'  => trim($_POST['telefono'] ?? ''),
                'correo'    => trim($_POST['correo'] ?? '')
            ];

            if (!$id || in_array('', $datos, true)) {
                $_SESSION['error'] = 'Todos los campos son obligatorios.';
                header("Location: /PROYECTO_PELUCHE/admin/usuarioCliente/editarUsuario?id=$id");
                exit;
            }

            $ok = $this->modelo->actualizarUsuario($id, $datos);

            $this->logger->registrar(
                $_SESSION['usuario_admin']['id'] ?? null,
                'Actualizar',
                $ok ? "Se actualizó el usuario con ID $id." : "Fallo al actualizar el usuario con ID $id."
            );

            $_SESSION[$ok ? 'mensaje' : 'error'] = $ok 
                ? 'Usuario actualizado correctamente.' 
                : 'Error al actualizar usuario.';

            header("Location: /PROYECTO_PELUCHE/admin/usuarioCliente/listarClientes");
            exit;
        }
    }

    public function eliminarUsuario() {
        if (!isset($_GET['id'])) {
            $_SESSION['error'] = 'ID no especificado.';
            header("Location: /PROYECTO_PELUCHE/admin/usuarioCliente/listarClientes");
            exit;
        }

        $id = (int)$_GET['id'];
        $ok = $this->modelo->desactivarUsuario($id);

        $this->logger->registrar(
            $_SESSION['usuario_admin']['id'] ?? null,
            'Eliminar',
            $ok ? "Se desactivó el usuario con ID $id." : "Fallo al desactivar el usuario con ID $id."
        );

        $_SESSION[$ok ? 'mensaje' : 'error'] = $ok 
            ? 'Usuario desactivado correctamente.' 
            : 'Error al desactivar usuario.';

        header("Location: /PROYECTO_PELUCHE/admin/usuarioCliente/listarClientes");
        exit;
    }
}


<?php
require_once __DIR__ . '/../models/ADFranquiciaDAO.php';
require_once __DIR__ . '/../../app/models/LoggerWeb.php';

class ADFranquiciaController {
    private ADFranquiciaDAO $modelo;
    private LoggerWeb $logger;

    public function __construct() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $this->modelo = new ADFranquiciaDAO();
        $this->logger = new LoggerWeb();
    }

    public function mostrarFormularioFranquicia() {
        $this->logger->registrar($_SESSION['usuario_id'] ?? null, 'Vista', 'Accedió al formulario de registro de franquicia');
        require_once __DIR__ . '/../views/franquicia/Vista_Registro_Franquicia.php';
    }

    public function procesarRegistro() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre = trim($_POST['nombre_fran'] ?? '');

            if ($nombre === '') {
                $_SESSION['error'] = 'El nombre de la franquicia es obligatorio.';
                header("Location: /PROYECTO_PELUCHE/admin/franquicia/mostrarFormularioFranquicia");
                exit;
            }

            $registrado = $this->modelo->registrarFranquicia($nombre);

            $this->logger->registrar(
                $_SESSION['usuario_id'] ?? null,
                $registrado ? 'Registro' : 'Error',
                $registrado ? "Registró franquicia: $nombre" : "Fallo al registrar franquicia: $nombre"
            );

            $_SESSION[$registrado ? 'mensaje' : 'error'] = $registrado 
                ? 'Franquicia registrada correctamente.'
                : 'Error al registrar la franquicia.';

            header("Location: /PROYECTO_PELUCHE/admin/franquicia/mostrarFormularioFranquicia");
            exit;
        }
    }

    public function listarFranquicias() {
        $this->logger->registrar($_SESSION['usuario_id'] ?? null, 'Vista', 'Listó franquicias');
        $franquicias = $this->modelo->obtenerTodas();
        require_once __DIR__ . '/../views/franquicia/Vista_Listado_Franquicias.php';
    }

    public function editarFranquicia() {
        if (!isset($_GET['id'])) {
            $_SESSION['error'] = 'ID no proporcionado.';
            header("Location: /PROYECTO_PELUCHE/admin/franquicia/listarFranquicias");
            exit;
        }

        $id = intval($_GET['id']);
        $franquicia = $this->modelo->obtenerPorId($id);

        if (!$franquicia) {
            $_SESSION['error'] = 'Franquicia no encontrada.';
            header("Location: /PROYECTO_PELUCHE/admin/franquicia/listarFranquicias");
            exit;
        }

        $this->logger->registrar($_SESSION['usuario_id'] ?? null, 'Vista', "Accedió a edición de franquicia ID: $id");
        require_once __DIR__ . '/../views/franquicia/Vista_Editar_Franquicia.php';
    }

    public function procesarActualizacion() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = intval($_POST['id_franquicia'] ?? 0);
            $nombre = trim($_POST['nombre_fran'] ?? '');
            $estado = intval($_POST['estado_activo'] ?? 0);

            if (!$id || $nombre === '') {
                $_SESSION['error'] = 'Todos los campos son obligatorios.';
                header("Location: /PROYECTO_PELUCHE/admin/franquicia/editarFranquicia?id={$id}");
                exit;
            }

            $actualizado = $this->modelo->actualizarFranquicia($id, $nombre, $estado);

            $this->logger->registrar(
                $_SESSION['usuario_id'] ?? null,
                $actualizado ? 'Actualización' : 'Error',
                $actualizado 
                    ? "Actualizó franquicia ID: $id - Nuevo nombre: $nombre"
                    : "Fallo al actualizar franquicia ID: $id"
            );

            $_SESSION[$actualizado ? 'mensaje' : 'error'] = $actualizado 
                ? 'Franquicia actualizada correctamente.'
                : 'Error al actualizar la franquicia.';

            header("Location: /PROYECTO_PELUCHE/admin/franquicia/listarFranquicias");
            exit;
        }
    }

    public function eliminarFranquicia() {
        if (!isset($_GET['id'])) {
            $_SESSION['error'] = 'ID no proporcionado.';
            header("Location: /PROYECTO_PELUCHE/admin/franquicia/listarFranquicias");
            exit;
        }

        $id = intval($_GET['id']);
        $eliminado = $this->modelo->eliminarFranquicia($id);

        $this->logger->registrar(
            $_SESSION['usuario_id'] ?? null,
            $eliminado ? 'Eliminación' : 'Error',
            $eliminado 
                ? "Eliminó franquicia ID: $id"
                : "Fallo al eliminar franquicia ID: $id"
        );

        $_SESSION[$eliminado ? 'mensaje' : 'error'] = $eliminado
            ? 'Franquicia eliminada correctamente.'
            : 'Error al eliminar la franquicia.';

        header("Location: /PROYECTO_PELUCHE/admin/franquicia/listarFranquicias");
        exit;
    }
}

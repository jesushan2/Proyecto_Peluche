<?php
if (session_status() === PHP_SESSION_NONE) session_start();

require_once __DIR__ . '/../../app/models/LoggerWeb.php';

class ADInicioController
{
    private LoggerWeb $logger;

    public function __construct()
    {
        $this->logger = new LoggerWeb();
    }

    public function index()
    {
        if (!isset($_SESSION['usuario_id']) || !isset($_SESSION['usuario_rol']) || !isset($_SESSION['usuario_nombre'])) {
            header('Location: /PROYECTO_PELUCHE/admin/login/index');
            exit;
        }

        $this->logger->registrar(
            $_SESSION['usuario_id'] ?? null,
            'Vista',
            'Ingresó al panel de inicio del administrador'
        );

        require_once __DIR__ . '/../views/inicio/Vista_Inicio.php';
    }
}

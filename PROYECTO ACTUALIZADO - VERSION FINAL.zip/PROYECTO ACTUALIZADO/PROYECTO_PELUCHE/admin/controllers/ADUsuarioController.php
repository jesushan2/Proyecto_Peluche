<?php
require_once __DIR__ . '/../models/ADUsuarioDAO.php';
require_once __DIR__ . '/../../app/models/LoggerWeb.php';


class ADUsuarioController {
    private ADUsuarioDAO $modelo;
    private LoggerWeb $logger;

    public function __construct() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $this->modelo = new ADUsuarioDAO();
        $this->logger = new LoggerWeb();
    }

    public function mostrarFormularioAdministrador() {
        require_once __DIR__ . '/../views/usuarios/Vista_Registro_Administrador.php';
    }

    public function procesarRegistroAdministrador() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $datos = [
                'nombres' => htmlspecialchars(trim($_POST['nombres'] ?? '')),
                'apellidos' => htmlspecialchars(trim($_POST['apellidos'] ?? '')),
                'telefono' => htmlspecialchars(trim($_POST['telefono'] ?? '')),
                'correo' => filter_var($_POST['correo'] ?? '', FILTER_VALIDATE_EMAIL),
                'clave' => $_POST['clave'] ?? ''
            ];

            if (in_array('', $datos, true) || !$datos['correo']) {
                $_SESSION['error'] = 'Todos los campos son obligatorios y válidos.';
                header("Location: /PROYECTO_PELUCHE/admin/usuario/registroAdmin");
                exit;
            }

            if ($this->modelo->correoExiste($datos['correo'])) {
                $_SESSION['error'] = 'El correo ya está registrado.';
                header("Location: /PROYECTO_PELUCHE/admin/usuario/registroAdmin");
                exit;
            }

            $registrado = $this->modelo->registrarAdministrador($datos);

            if ($registrado) {
                $this->logger->registrar($_SESSION['id_usuario'] ?? null, 'Registro Admin', 'Administrador registrado: ' . $datos['correo']);
                $_SESSION['mensaje'] = 'Administrador registrado con éxito.';
            } else {
                $_SESSION['error'] = 'Error al registrar. Intente de nuevo.';
            }

            header("Location: /PROYECTO_PELUCHE/admin/usuario/mostrarFormularioAdministrador");
            exit;
        }
    }

    public function mostrarFormularioVendedor() {
        require_once __DIR__ . '/../views/usuarios/Vista_Registro_Vendedor.php';
    }

    public function procesarRegistroVendedor() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombres   = trim($_POST['nombres'] ?? '');
            $apellidos = trim($_POST['apellidos'] ?? '');
            $telefono  = trim($_POST['telefono'] ?? '');
            $correo    = trim($_POST['correo'] ?? '');
            $clave     = trim($_POST['clave'] ?? '');

            if (!$nombres || !$apellidos || !$telefono || !$correo || !$clave) {
                $_SESSION['error'] = 'Todos los campos son obligatorios.';
                header("Location: /PROYECTO_PELUCHE/admin/usuario/registroVendedor");
                exit;
            }

            if ($this->modelo->existeCorreoVendedor($correo)) {
                $_SESSION['error'] = 'El correo ya está registrado.';
                header("Location: /PROYECTO_PELUCHE/admin/usuario/registroVendedor");
                exit;
            }

            $claveHash = password_hash($clave, PASSWORD_DEFAULT);
            $exito = $this->modelo->registrarVendedor($nombres, $apellidos, $telefono, $correo, $claveHash);

            if ($exito) {
                $this->logger->registrar($_SESSION['id_usuario'] ?? null, 'Registro Vendedor', "Vendedor registrado: $correo");
                $_SESSION['mensaje'] = 'Vendedor registrado correctamente.';
                header("Location: /PROYECTO_PELUCHE/admin/usuario/mostrarFormularioVendedor");
            } else {
                $_SESSION['error'] = 'Error al registrar vendedor.';
                header("Location: /PROYECTO_PELUCHE/admin/usuario/registroVendedor");
            }
            exit;
        }
    }

    public function listarAdministradores() {
        $admins = $this->modelo->obtenerAdministradoresActivos();
        $this->logger->registrar($_SESSION['id_usuario'] ?? null, 'Ver Admins', 'Se listaron administradores activos');
        require_once __DIR__ . '/../views/usuarios/Vista_Listado_Administradores.php';
    }

    public function listarVendedores() {
        $vendedores = $this->modelo->obtenerVendedoresActivos();
        $this->logger->registrar($_SESSION['id_usuario'] ?? null, 'Ver Vendedores', 'Se listaron vendedores activos');
        require_once __DIR__ . '/../views/usuarios/Vista_Listado_Vendedores.php';
    }

    public function editarAdministrador() {
        $id = $_GET['id'] ?? null;
        $admin = $this->modelo->obtenerAdminPorId($id);
        if (!$admin) {
            $_SESSION['error'] = "Administrador no encontrado.";
            header("Location: /PROYECTO_PELUCHE/admin/usuario/listarAdministradores");
            exit;
        }
        require_once __DIR__ . '/../views/usuarios/Vista_Editar_Administrador.php';
    }

    public function procesarEditarAdministrador() {
        $id = $_POST['id_admin'];
        $datos = [
            'nombres' => $_POST['nombres'],
            'apellidos' => $_POST['apellidos'],
            'telefono' => $_POST['telefono'],
            'correo' => $_POST['correo']
        ];
        $this->modelo->actualizarAdministrador($id, $datos);
        $this->logger->registrar($_SESSION['id_usuario'] ?? null, 'Editar Admin', "Administrador ID $id actualizado.");
        $_SESSION['mensaje'] = 'Administrador actualizado correctamente.';
        header("Location: /PROYECTO_PELUCHE/admin/usuario/listarAdministradores");
        exit;
    }

    public function editarVendedor() {
        $id = $_GET['id'] ?? null;
        $vendedor = $this->modelo->obtenerVendedorPorId($id);
        if (!$vendedor) {
            $_SESSION['error'] = "Vendedor no encontrado.";
            header("Location: /PROYECTO_PELUCHE/admin/usuario/listarVendedores");
            exit;
        }
        require_once __DIR__ . '/../views/usuarios/Vista_Editar_Vendedor.php';
    }

    public function procesarEditarVendedor() {
        $id = $_POST['id_vendedor'];
        $datos = [
            'nombres' => $_POST['nombres'],
            'apellidos' => $_POST['apellidos'],
            'telefono' => $_POST['telefono'],
            'correo' => $_POST['correo']
        ];
        $this->modelo->actualizarVendedor($id, $datos);
        $this->logger->registrar($_SESSION['id_usuario'] ?? null, 'Editar Vendedor', "Vendedor ID $id actualizado.");
        $_SESSION['mensaje'] = 'Vendedor actualizado correctamente.';
        header("Location: /PROYECTO_PELUCHE/admin/usuario/listarVendedores");
        exit;
    }

    public function eliminarAdministrador() {
        $id = $_GET['id'] ?? 0;
        $this->modelo->desactivarAdministrador($id);
        $this->logger->registrar($_SESSION['id_usuario'] ?? null, 'Eliminar Admin', "Administrador ID $id desactivado.");
        $_SESSION['mensaje'] = 'Administrador desactivado correctamente.';
        header("Location: /PROYECTO_PELUCHE/admin/usuario/listarAdministradores");
        exit;
    }

    public function eliminarVendedor() {
        $id = $_GET['id'] ?? 0;
        $this->modelo->desactivarVendedor($id);
        $this->logger->registrar($_SESSION['id_usuario'] ?? null, 'Eliminar Vendedor', "Vendedor ID $id desactivado.");
        $_SESSION['mensaje'] = 'Vendedor desactivado correctamente.';
        header("Location: /PROYECTO_PELUCHE/admin/usuario/listarVendedores");
        exit;
    }
}

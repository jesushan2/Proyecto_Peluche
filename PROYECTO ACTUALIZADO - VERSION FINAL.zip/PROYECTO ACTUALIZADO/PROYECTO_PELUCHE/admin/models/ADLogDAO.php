<?php
require_once __DIR__ . '/../../config/database.php';

class ADLogDAO {
    private PDO $conexion;

    public function __construct() {
        $this->conexion = Database::connect();
    }

    public function obtenerTodosLogs(): array {
        $stmt = $this->conexion->query("SELECT * FROM logs_web ORDER BY id_log DESC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

<?php
require_once __DIR__ . '/../../config/database.php';

class ADLoginDAO {
    private PDO $conexion;

    public function __construct() {
        $this->conexion = Database::connect();
    }

    public function obtenerUsuarioPorCorreo(string $correo): ?array {
        try {
            $stmt = $this->conexion->prepare("CALL sp_obtener_usuario_login(:correo)");
            $stmt->execute([':correo' => $correo]);
            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
            return $usuario ?: null;
        } catch (PDOException $e) {
            error_log("Error en obtenerUsuarioPorCorreo: " . $e->getMessage());
            return null;
        }
    }
}

<?php
require_once __DIR__ . '/../../config/database.php';

class ADReservaDAO {
    private $conexion;

    public function __construct() {
        $this->conexion = Database::connect();
    }

    public function obtenerReservasPorVendedor($id_vendedor) {
        $stmt = $this->conexion->prepare("CALL sp_obtener_reservas_por_vendedor(?)");
        $stmt->execute([$id_vendedor]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerTodasReservas() {
        $stmt = $this->conexion->query("CALL sp_obtener_todas_reservas()");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerIdUsuarioPorReserva(int $id_reserva): ?int {
        $stmt = $this->conexion->prepare("CALL sp_obtener_id_usuario_por_reserva(?)");
        $stmt->execute([$id_reserva]);
        $id = $stmt->fetchColumn();
        return $id !== false ? (int)$id : null;
    }

    public function obtenerNombreEstadoPorId(int $id_estado): ?string {
        $stmt = $this->conexion->prepare("CALL sp_obtener_nombre_estado_por_id(?)");
        $stmt->execute([$id_estado]);
        $nombre = $stmt->fetchColumn();
        return $nombre !== false ? $nombre : null;
    }

    public function registrarNotificacion(int $id_usuario, int $id_reserva, string $mensaje): bool {
        $stmt = $this->conexion->prepare("CALL sp_registrar_notificacion(?, ?, ?)");
        return $stmt->execute([$id_usuario, $id_reserva, $mensaje]);
    }

    public function obtenerReservaPorId($id) {
        $stmt = $this->conexion->prepare("CALL sp_obtener_reserva_por_id(?)");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function editarReserva($id_reserva, $id_estado_nuevo, $id_vendedor) {

        $sql = "SELECT id_estado FROM reservas WHERE id_reserva = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute([$id_reserva]);
        $estadoAnterior = $stmt->fetchColumn();

        $stmtUpdate = $this->conexion->prepare("CALL sp_editar_reserva(?, ?, ?)");
        $resultado = $stmtUpdate->execute([
            $id_reserva,
            $id_estado_nuevo,
            $id_vendedor ?: 0
        ]);

        return $resultado ? (int)$estadoAnterior : false;
    }

    public function desactivarReserva($id) {
        $stmt = $this->conexion->prepare("CALL sp_desactivar_reserva(?)");
        return $stmt->execute([$id]);
    }

    public function obtenerEstados() {
        $stmt = $this->conexion->query("CALL sp_obtener_estados_reserva()");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerVendedores() {
        $stmt = $this->conexion->query("CALL sp_obtener_vendedores_reserva()");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function registrarHistorial($id_reserva, $id_estado_anterior, $id_estado_nuevo, $id_admin = null, $id_vendedor = null) {
        $stmt = $this->conexion->prepare("CALL sp_registrar_historial_reserva(?, ?, ?, ?, ?)");
        return $stmt->execute([
            $id_reserva,
            $id_estado_anterior,
            $id_estado_nuevo,
            $id_admin,
            $id_vendedor
        ]);
    }

    public function obtenerHistorialPorReserva($id_reserva) {
        $stmt = $this->conexion->prepare("CALL sp_obtener_historial_reserva(?)");
        $stmt->execute([$id_reserva]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

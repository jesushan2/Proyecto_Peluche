<?php
require_once __DIR__ . '/../../config/database.php';

class ADUsuarioClienteDAO {
    private PDO $conexion;

    public function __construct() {
        $this->conexion = Database::connect();
    }

    public function obtenerTodos(): array {
        try {
            $stmt = $this->conexion->query("CALL sp_obtener_usuarios_activos()");
            $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $stmt->closeCursor(); 
            return $resultado;
        } catch (PDOException $e) {
            error_log("Error en obtenerTodos: " . $e->getMessage());
            return [];
        }
    }

    public function obtenerPorId(int $id): ?array {
        try {
            $stmt = $this->conexion->prepare("CALL sp_obtener_usuario_por_id(:id)");
            $stmt->execute([':id' => $id]);
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            $stmt->closeCursor();
            return $resultado ?: null;
        } catch (PDOException $e) {
            error_log("Error en obtenerPorId: " . $e->getMessage());
            return null;
        }
    }
    public function actualizarUsuario(int $id, array $datos): bool {
        try {
            $stmt = $this->conexion->prepare("CALL sp_actualizar_usuario(:id, :nombres, :apellidos, :telefono, :correo)");
            $stmt->execute([
                ':id'        => $id,
                ':nombres'   => $datos['nombres'],
                ':apellidos' => $datos['apellidos'],
                ':telefono'  => $datos['telefono'],
                ':correo'    => $datos['correo']
            ]);
            $stmt->closeCursor();
            return true;
        } catch (PDOException $e) {
            error_log("Error en actualizarUsuario: " . $e->getMessage());
            return false;
        }
    }

    public function desactivarUsuario(int $id): bool {
        try {
            $stmt = $this->conexion->prepare("CALL sp_desactivar_usuario(:id)");
            $stmt->execute([':id' => $id]);
            $stmt->closeCursor();
            return true;
        } catch (PDOException $e) {
            error_log("Error en desactivarUsuario: " . $e->getMessage());
            return false;
        }
    }
}


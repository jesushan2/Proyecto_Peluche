<?php
require_once __DIR__ . '/../../config/database.php';

class ADUsuarioDAO {
    private PDO $conexion;

    public function __construct() {
        $this->conexion = Database::connect();
    }

    public function correoExiste(string $correo): bool {
        $stmt = $this->conexion->prepare("CALL sp_correo_admin_existe(?)");
        $stmt->execute([$correo]);
        $resultado = $stmt->fetch();
        $stmt->closeCursor();
        return $resultado !== false;
    }

    public function registrarAdministrador(array $datos): bool {
        try {
            $stmt = $this->conexion->prepare("CALL sp_registrar_administrador(?, ?, ?, ?, ?)");
            return $stmt->execute([
                $datos['nombres'],
                $datos['apellidos'],
                $datos['telefono'],
                $datos['correo'],
                password_hash($datos['clave'], PASSWORD_DEFAULT)
            ]);
        } catch (PDOException $e) {
            error_log("Error en registrarAdministrador: " . $e->getMessage());
            return false;
        }
    }

    public function existeCorreoVendedor(string $correo): bool {
        $stmt = $this->conexion->prepare("CALL sp_correo_vendedor_existe(?)");
        $stmt->execute([$correo]);
        $resultado = $stmt->fetch();
        $stmt->closeCursor();
        return $resultado !== false;
    }

    public function registrarVendedor(string $nombres, string $apellidos, string $telefono, string $correo, string $clave): bool {
        try {
            $stmt = $this->conexion->prepare("CALL sp_registrar_vendedor(?, ?, ?, ?, ?)");
            return $stmt->execute([$nombres, $apellidos, $telefono, $correo, $clave]);
        } catch (PDOException $e) {
            error_log("Error en registrarVendedor: " . $e->getMessage());
            return false;
        }
    }

    public function obtenerAdministradoresActivos(): array {
        $stmt = $this->conexion->query("CALL sp_obtener_admins_activos()");
        $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $stmt->closeCursor();
        return $resultado;
    }

    public function obtenerAdminPorId(int $id): ?array {
        $stmt = $this->conexion->prepare("CALL sp_obtener_admin_por_id(?)");
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        $stmt->closeCursor();
        return $resultado ?: null;
    }

    public function actualizarAdministrador(int $id, array $datos): bool {
        $stmt = $this->conexion->prepare("CALL sp_actualizar_admin(?, ?, ?, ?, ?)");
        return $stmt->execute([
            $id,
            $datos['nombres'],
            $datos['apellidos'],
            $datos['telefono'],
            $datos['correo']
        ]);
    }

    public function desactivarAdministrador(int $id): bool {
        $stmt = $this->conexion->prepare("CALL sp_desactivar_admin(?)");
        return $stmt->execute([$id]);
    }

    public function obtenerVendedoresActivos(): array {
        $stmt = $this->conexion->query("CALL sp_obtener_vendedores_activos()");
        $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $stmt->closeCursor();
        return $resultado;
    }

    public function obtenerVendedorPorId(int $id): ?array {
        $stmt = $this->conexion->prepare("CALL sp_obtener_vendedor_por_id(?)");
        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        $stmt->closeCursor();
        return $resultado ?: null;
    }

    public function actualizarVendedor(int $id, array $datos): bool {
        $stmt = $this->conexion->prepare("CALL sp_actualizar_vendedor(?, ?, ?, ?, ?)");
        return $stmt->execute([
            $id,
            $datos['nombres'],
            $datos['apellidos'],
            $datos['telefono'],
            $datos['correo']
        ]);
    }

    public function desactivarVendedor(int $id): bool {
        $stmt = $this->conexion->prepare("CALL sp_desactivar_vendedor(?)");
        return $stmt->execute([$id]);
    }
}

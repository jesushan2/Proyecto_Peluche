<?php
require_once __DIR__ . '/../../config/database.php';

class ADFranquiciaDAO {
    private PDO $conexion;

    public function __construct() {
        $this->conexion = Database::connect();
    }

    public function registrarFranquicia(string $nombre): bool {
        try {
            $stmt = $this->conexion->prepare("CALL sp_registrar_franquicia(:nombre)");
            return $stmt->execute([
                ':nombre' => $nombre
            ]);
        } catch (PDOException $e) {
            error_log("Error en registrarFranquicia: " . $e->getMessage());
            return false;
        }
    }

    public function obtenerTodas(): array {
        try {
            $stmt = $this->conexion->query("CALL sp_obtener_franquicias_activas()");
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error en obtenerTodas: " . $e->getMessage());
            return [];
        }
    }

    public function eliminarFranquicia(int $id): bool {
        try {
            $stmt = $this->conexion->prepare("CALL sp_eliminar_franquicia(:id)");
            return $stmt->execute([':id' => $id]);
        } catch (PDOException $e) {
            error_log("Error en eliminarFranquicia: " . $e->getMessage());
            return false;
        }
    }

    public function actualizarFranquicia(int $id, string $nuevoNombre, int $estado): bool {
        try {
            $stmt = $this->conexion->prepare("CALL sp_actualizar_franquicia(:id, :nombre, :estado)");
            return $stmt->execute([
                ':id' => $id,
                ':nombre' => $nuevoNombre,
                ':estado' => $estado
            ]);
        } catch (PDOException $e) {
            error_log("Error en actualizarFranquicia: " . $e->getMessage());
            return false;
        }
    }

    public function obtenerPorId(int $id): ?array {
        try {
            $stmt = $this->conexion->prepare("CALL sp_obtener_franquicia_por_id(:id)");
            $stmt->execute([':id' => $id]);
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado ?: null;
        } catch (PDOException $e) {
            error_log("Error en obtenerPorId: " . $e->getMessage());
            return null;
        }
    }
}

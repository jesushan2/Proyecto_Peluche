<?php
require_once __DIR__ . '/../../config/database.php';

class ADEstadisticasDAO {
    private $conn;

    public function __construct() {
        $this->conn = Database::connect();
    }

    public function contarReservasHoy() {
        $stmt = $this->conn->query("SELECT COUNT(*) AS total FROM reservas WHERE DATE(fecha_reserva) = CURDATE()");
        return $stmt->fetch()['total'] ?? 0;
    }

    public function contarReservasSemana() {
        $stmt = $this->conn->query("SELECT COUNT(*) AS total FROM reservas WHERE YEARWEEK(fecha_reserva, 1) = YEARWEEK(CURDATE(), 1)");
        return $stmt->fetch()['total'] ?? 0;
    }

    public function contarReservasMes() {
        $stmt = $this->conn->query("SELECT COUNT(*) AS total FROM reservas WHERE YEAR(fecha_reserva) = YEAR(CURDATE()) AND MONTH(fecha_reserva) = MONTH(CURDATE())");
        return $stmt->fetch()['total'] ?? 0;
    }

    public function obtenerReservasPorEstado() {
        $stmt = $this->conn->query("
            SELECT e.nombre_est, COUNT(r.id_reserva) AS total
            FROM reservas r
            JOIN estados_reserva e ON r.id_estado = e.id_estado
            GROUP BY e.id_estado
        ");
        return $stmt->fetchAll();
    }

    public function obtenerTopProductos() {
        $stmt = $this->conn->query("
            SELECT p.nombre_prod, SUM(d.cantidad) AS total_reservado
            FROM detalles_reserva d
            JOIN productos p ON d.id_producto = p.id_producto
            GROUP BY d.id_producto
            ORDER BY total_reservado DESC
            LIMIT 5
        ");
        return $stmt->fetchAll();
    }

    public function contarUsuariosActivos() {
        $stmt = $this->conn->query("SELECT COUNT(*) AS total FROM usuarios WHERE estado_activo = 1");
        return $stmt->fetch()['total'] ?? 0;
    }

    public function contarVendedoresActivos() {
        $stmt = $this->conn->query("SELECT COUNT(*) AS total FROM vendedores WHERE estado_activo = 1");
        return $stmt->fetch()['total'] ?? 0;
    }

    public function obtenerUltimosLogs() {
        $stmt = $this->conn->query("
            SELECT l.accion, l.descripcion, l.ip_usuario, l.fecha, u.nombres, u.apellidos
            FROM logs_web l
            LEFT JOIN usuarios u ON l.id_usuario = u.id_usuario
            ORDER BY l.fecha DESC
            LIMIT 10
        ");
        return $stmt->fetchAll();
    }
}

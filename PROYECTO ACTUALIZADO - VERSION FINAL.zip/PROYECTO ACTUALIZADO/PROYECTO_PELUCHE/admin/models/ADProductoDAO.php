<?php
require_once __DIR__ . '/../../config/database.php';

class ADProductoDAO {
    private PDO $conexion;

    public function __construct() {
        $this->conexion = Database::connect();
    }

    public function registrarProducto(array $datos): bool {
        try {
            $stmt = $this->conexion->prepare("CALL sp_registrar_producto(?, ?, ?, ?, ?, ?, ?, ?)");
            return $stmt->execute([
                $datos['id_franquicia'],
                $datos['nombre_prod'],
                $datos['descripcion'],
                $datos['altura'],
                $datos['color'],
                $datos['stock'],
                $datos['precio'],
                $datos['imagen']
            ]);
        } catch (PDOException $e) {
            error_log("Error en registrarProducto: " . $e->getMessage());
            return false;
        }
    }

    public function obtenerFranquicias(): array {
        $sql = "SELECT id_franquicia, nombre_fran FROM franquicias WHERE estado_activo = 1";
        return $this->conexion->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerTodosProductos(): array {
        try {
            $stmt = $this->conexion->query("CALL sp_obtener_todos_productos()");
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error en obtenerTodosProductos: " . $e->getMessage());
            return [];
        }
    }

    public function obtenerProductoPorId($id): ?array {
        try {
            $stmt = $this->conexion->prepare("CALL sp_obtener_producto_por_id(?)");
            $stmt->execute([$id]);
            return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
        } catch (PDOException $e) {
            error_log("Error en obtenerProductoPorId: " . $e->getMessage());
            return null;
        }
    }

    public function editarProducto(int $id, array $datos): bool {
        try {
            $stmt = $this->conexion->prepare("CALL sp_editar_producto(?, ?, ?, ?, ?, ?, ?, ?, ?)");
            return $stmt->execute([
                $id,
                $datos['id_franquicia'],
                $datos['nombre_prod'],
                $datos['descripcion'],
                $datos['altura'],
                $datos['color'],
                $datos['stock'],
                $datos['precio'],
                $datos['imagen']
            ]);
        } catch (PDOException $e) {
            error_log("Error en editarProducto: " . $e->getMessage());
            return false;
        }
    }

    public function desactivarProducto(int $id): bool {
        try {
            $stmt = $this->conexion->prepare("CALL sp_desactivar_producto(?)");
            return $stmt->execute([$id]);
        } catch (PDOException $e) {
            error_log("Error en desactivarProducto: " . $e->getMessage());
            return false;
        }
    }
}
